#pragma once

#include <cstdint>

namespace cdls::cuda_detail::getrf {

// One address representation for all matrix sizes and strides.
using MatrixIndex = std::int64_t;

// CUDA execution geometry. Warp width is a hardware constraint, not a tuning
// knob.
inline constexpr int kWarpSize = 32;
inline constexpr unsigned kWarpMask = 0xffffffffu;
inline constexpr int kWarpsPerTile = 8;
inline constexpr int kTileThreads = kWarpSize * kWarpsPerTile;

// Compile-time algorithm geometry. Derived dimensions must remain consistent.
inline constexpr int kTileExtent = 64;
inline constexpr int kRegisterAxis = 16;
inline constexpr int kRegisterValues = kTileExtent / kRegisterAxis;
inline constexpr unsigned kRhsLanes = kTileThreads / kTileExtent;
inline constexpr unsigned kRhsValues = kTileExtent / kRhsLanes;
inline constexpr int kCopyRowLanes = 16;
inline constexpr int kPanelWidth = 16;
inline constexpr int kCopyK = 16;
inline constexpr int kSharedPadding = 1;
inline constexpr int kVectorCopyBytes = 16;
inline constexpr int kNoPivotStages = 3;
inline constexpr int kStaticPivotStages = 4;
inline constexpr int kDependencySleepNs = 40;

static_assert(kWarpSize == 32, "CUDA warp operations require 32 lanes");
static_assert(kTileThreads == kRegisterAxis * kRegisterAxis);
static_assert(kTileExtent % kRegisterAxis == 0);
static_assert(kTileExtent % kPanelWidth == 0);
static_assert(kTileExtent % kCopyK == 0);
static_assert(kTileExtent % kRhsLanes == 0);
static_assert(kWarpSize % kRhsLanes == 0);

// Measured A100 dispatch policy, separate from the mathematical tile geometry.
inline constexpr int kFusedMaxExtent = 4224;
inline constexpr int kBalancedMinBlocks = 2;
inline constexpr int kLargeRegisterMinBlocks = 1;
inline constexpr int kHybridPanelExtent = 2048;
inline constexpr int kHybridTargetTailExtent = 3072;

}  // namespace cdls::cuda_detail::getrf
