#pragma once

#include <cstddef>
#include <cuda/atomic>
#include <cute/config.hpp>
#include <limits>

#include "../../common/getrf/schedule.h"
#include "config.cuh"

namespace cdls::cuda_detail::getrf {

// The caller owns storage; each launch resets it on the execution stream.
// CTAs claim indices relaxed and release-publish completed matrix tiles.
template <class T>
using TaskAtomic = cuda::atomic<T, cuda::thread_scope_device>;

struct TaskWorkspace {
  TaskAtomic<int>* next;
  TaskAtomic<bool>* complete;

  explicit TaskWorkspace(void* storage)
      : next(reinterpret_cast<TaskAtomic<int>*>(storage)),
        complete(reinterpret_cast<TaskAtomic<bool>*>(
            static_cast<std::byte*>(storage) + sizeof(TaskAtomic<int>))) {}

  // The task counter and scheduling arithmetic use signed int indices.
  static bool supports_extent(MatrixIndex n) {
    if (n <= 0) return false;
    const auto tiles = (n - 1) / kTileExtent + 1;
    return tiles <= std::numeric_limits<int>::max() / tiles;
  }

  // Requires supports_extent(n); no narrowing of the public matrix extent.
  static size_t bytes(MatrixIndex n) {
    const size_t tiles = (n - 1) / kTileExtent + 1;
    return sizeof(TaskAtomic<int>) + sizeof(TaskAtomic<bool>) * tiles * tiles;
  }
};

using cdls::detail::getrf::index_to_coord;
using cdls::detail::getrf::TileCoord;

}  // namespace cdls::cuda_detail::getrf
