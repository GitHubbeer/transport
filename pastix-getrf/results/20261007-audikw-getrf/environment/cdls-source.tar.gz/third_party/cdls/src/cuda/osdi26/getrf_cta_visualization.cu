#include <cdls/common.h>
#include <cdls/internal/common.h>
#include <cusolverDn.h>
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

#include <chrono>
#include <cstdio>
#include <cuda/atomic>
#include <cute/tensor.hpp>
#include <cxxopts.hpp>
#include <fstream>
#include <random>

namespace {
template <typename IndexType>
CUTE_HOST_DEVICE auto index_to_coord(const IndexType index, const IndexType M) {
  IndexType left = 0, right = M - 1;
  IndexType k = 0;
  while (left <= right) {
    const IndexType mid = left + (right - left) / 2;
    const IndexType curr = mid * (2 * M - mid);
    const IndexType next = (mid + 1) * (2 * M - (mid + 1));

    if (curr <= index && index < next) {
      k = mid;
      break;
    }
    if (curr > index) {
      right = mid - 1;
    } else {
      left = mid + 1;
    }
  }

  const IndexType base = k * (2 * M - k);

  const IndexType offset = index - base;
  IndexType i_prime, j_prime;

  if (offset == 0) {
    i_prime = 0;
    j_prime = 0;
  } else if (offset % 2 == 1) {
    const IndexType t = (offset + 1) / 2;
    i_prime = t;
    j_prime = 0;
  } else {
    const IndexType t = offset / 2;
    i_prime = 0;
    j_prime = t;
  }

  return std::make_tuple(k + i_prime, k + j_prime);
}

template <bool enable_static_pivoting, typename PredRow, typename PredCol,
          typename TensorGmem, typename TensorSmem, typename TensorRmem>
CUTE_DEVICE void lu_16x16(const unsigned lane_id, const PredRow& pred_row,
                          const PredCol& pred_col, TensorGmem&& gmem,
                          TensorSmem&& smem, TensorRmem& rmem,
                          cuda::atomic<int>* const pivot_count_ptr) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(gmem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rmem) == _1{});

  CUTE_STATIC_ASSERT_V(size<0>(gmem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(gmem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rmem) == _8{});

  static_assert(std::is_same_v<typename TensorGmem::value_type,
                               typename TensorSmem::value_type>);
  static_assert(std::is_same_v<typename TensorGmem::value_type,
                               typename TensorRmem::value_type>);

  using T = typename TensorSmem::value_type;

  auto& factor = rmem;

  T u[16 / 2];

  CUTE_UNROLL
  for (int factorize_col = 0; factorize_col < 16; ++factorize_col) {
    const int pivot_lane_id = factorize_col % 2 * 16 + factorize_col;
    if constexpr (enable_static_pivoting) {
      if (lane_id == pivot_lane_id) {
        if (factor[factorize_col / 2] > -std::numeric_limits<T>::epsilon() &&
            factor[factorize_col / 2] < std::numeric_limits<T>::epsilon()) {
          factor[factorize_col / 2] = factor[factorize_col / 2] > 0
                                          ? std::numeric_limits<T>::epsilon()
                                          : -std::numeric_limits<T>::epsilon();
          pivot_count_ptr->fetch_add(1, cuda::memory_order_relaxed);
        }
      }
    }
    T pivot = __shfl_sync(0xFFFFFFFF, factor[factorize_col / 2], pivot_lane_id);
    if (pivot_lane_id < lane_id && lane_id < (factorize_col % 2 + 1) * 16) {
      factor[factorize_col / 2] /= pivot;
    }

    if (factorize_col % 2 == 1) {
      if (pred_row(lane_id % 16)) {
        if (pred_col(factorize_col - static_cast<int>(lane_id < 16))) {
          gmem[lane_id + factorize_col / 2 * 32] = factor[factorize_col / 2];
          smem[lane_id + factorize_col / 2 * 32] = factor[factorize_col / 2];
        }
      }
    }

    u[(factorize_col + 1) / 2] = 0;

    CUTE_UNROLL
    for (int broadcast_col = factorize_col + 1; broadcast_col < 16;
         ++broadcast_col) {
      if (broadcast_col % 2 == 0) {
        T val =
            __shfl_sync(0xFFFFFFFF, factor[broadcast_col / 2], factorize_col);
        if (lane_id < 16) {
          u[broadcast_col / 2] = val;
        }
      } else {
        T val = __shfl_sync(0xFFFFFFFF, factor[broadcast_col / 2],
                            factorize_col + 16);
        if (lane_id >= 16) {
          u[broadcast_col / 2] = val;
        }
      }
    }

    T l;

    if (factorize_col % 2 == 0) {
      l = __shfl_up_sync(0xFFFFFFFF, factor[factorize_col / 2], 16);
      if (lane_id < 16) {
        l = factor[factorize_col / 2];
      }
    } else {
      l = __shfl_down_sync(0xFFFFFFFF, factor[factorize_col / 2], 16);
      if (lane_id >= 16) {
        l = factor[factorize_col / 2];
      }
    }

    if (lane_id % 16 > factorize_col) {
      CUTE_UNROLL
      for (int update_col = (factorize_col + 1) / 2; update_col < 16 / 2;
           update_col++) {
        factor[update_col] -= l * u[update_col];
      }
    }
  }
}

template <typename Pred, typename TensorDiagSmem, typename TensorRhsGmem,
          typename TensorRhsSmem, typename TensorRhsRmem>
CUTE_DEVICE void lx_solve_16x16(const unsigned lane_id, const Pred& pred,
                                const TensorDiagSmem& diag_smem,
                                TensorRhsGmem&& rhs_gmem,
                                TensorRhsSmem&& rhs_smem,
                                TensorRhsRmem& rhs_rmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(diag_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rhs_gmem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rhs_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rhs_rmem) == _1{});

  CUTE_STATIC_ASSERT_V(size<0>(diag_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(diag_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rhs_gmem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(rhs_gmem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rhs_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(rhs_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rhs_rmem) == _8{});

  static_assert(std::is_same_v<typename TensorDiagSmem::value_type,
                               typename TensorRhsGmem::value_type>);
  static_assert(std::is_same_v<typename TensorDiagSmem::value_type,
                               typename TensorRhsSmem::value_type>);
  static_assert(std::is_same_v<typename TensorDiagSmem::value_type,
                               typename TensorRhsRmem::value_type>);

  using T = typename TensorDiagSmem::value_type;

  T l[16 / 2];

  auto& x = rhs_rmem;

  CUTE_UNROLL
  for (int col_group = 0; col_group < 16 / 2; ++col_group) {
    l[col_group] = diag_smem[lane_id + col_group * 32];
  }

  CUTE_UNROLL
  for (int solve_col_group = 0; solve_col_group < 16 / 2; ++solve_col_group) {
    CUTE_UNROLL
    for (int solve_row = 0; solve_row < 16; ++solve_row) {
      T solution;

      {
        T val;
        val = __shfl_sync(0xFFFFFFFF, x[solve_col_group], solve_row);
        if (lane_id < 16) {
          solution = val;
        }
        val = __shfl_sync(0xFFFFFFFF, x[solve_col_group], solve_row + 16);
        if (lane_id >= 16) {
          solution = val;
        }
      }

      T coef;

      if (solve_row % 2 == 0) {
        coef = __shfl_up_sync(0xFFFFFFFF, l[solve_row / 2], 16);
        if (lane_id < 16) {
          coef = l[solve_row / 2];
        }
      } else {
        coef = __shfl_down_sync(0xFFFFFFFF, l[solve_row / 2], 16);
        if (lane_id >= 16) {
          coef = l[solve_row / 2];
        }
      }

      if (lane_id % 16 > solve_row) {
        x[solve_col_group] -= coef * solution;
      }
    }

    if (pred(solve_col_group * 2 + static_cast<int>(lane_id >= 16))) {
      rhs_gmem[lane_id + solve_col_group * 32] = x[solve_col_group];
      rhs_smem[lane_id + solve_col_group * 32] = x[solve_col_group];
    }
  }
}

template <typename Pred, typename TensorDiag, typename TensorRhsGmem,
          typename TensorRhsSmem, typename TensorRhsRmem>
CUTE_DEVICE void xu_solve_16x16(const unsigned lane_id, const Pred& pred,
                                const TensorDiag& diag,
                                TensorRhsGmem&& rhs_gmem,
                                TensorRhsSmem&& rhs_smem,
                                TensorRhsRmem& rhs_rmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(diag) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rhs_gmem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rhs_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rhs_rmem) == _1{});

  CUTE_STATIC_ASSERT_V(size<0>(diag) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(diag) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rhs_gmem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(rhs_gmem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rhs_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(rhs_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rhs_rmem) == _8{});
  static_assert(is_same_v<typename TensorDiag::value_type,
                          typename TensorRhsGmem::value_type>);
  static_assert(is_same_v<typename TensorDiag::value_type,
                          typename TensorRhsSmem::value_type>);
  static_assert(is_same_v<typename TensorDiag::value_type,
                          typename TensorRhsRmem::value_type>);

  using T = typename TensorDiag::value_type;

  T u[16 / 2];

  auto& x = rhs_rmem;

  CUTE_UNROLL
  for (unsigned col_group = 0; col_group < 16 / 2; ++col_group) {
    u[col_group] = diag[lane_id + col_group * 32];
  }

  CUTE_UNROLL
  for (int solve_col = 0; solve_col < 16; ++solve_col) {
    const int pivot_lane_id = solve_col % 2 * 16 + solve_col;
    const T pivot = __shfl_sync(0xFFFFFFFF, u[solve_col / 2], pivot_lane_id);

    T solution;
    if (solve_col % 2 == 0) {
      if (lane_id < 16) {
        x[solve_col / 2] /= pivot;
      }
      solution = __shfl_up_sync(0xFFFFFFFF, x[solve_col / 2], 16);
      if (lane_id < 16) {
        solution = x[solve_col / 2];
      }
    } else {
      if (lane_id >= 16) {
        x[solve_col / 2] /= pivot;
      }
      solution = __shfl_down_sync(0xFFFFFFFF, x[solve_col / 2], 16);
      if (lane_id >= 16) {
        solution = x[solve_col / 2];
      }
    }

    if (solve_col % 2 == 1) {
      if (pred(lane_id % 16)) {
        rhs_gmem[lane_id + solve_col / 2 * 32] = x[solve_col / 2];
        rhs_smem[lane_id + solve_col / 2 * 32] = x[solve_col / 2];
      }
    }

    CUTE_UNROLL
    for (int update_col = solve_col + 1; update_col < 16; ++update_col) {
      if (update_col % 2 == 0) {
        T coef = __shfl_sync(0xFFFFFFFF, u[update_col / 2], solve_col);
        if (lane_id < 16) {
          x[update_col / 2] -= coef * solution;
        }
      } else {
        T coef = __shfl_sync(0xFFFFFFFF, u[update_col / 2], solve_col + 16);
        if (lane_id >= 16) {
          x[update_col / 2] -= coef * solution;
        }
      }
    }
  }
}

template <typename TensorA, typename TensorB, typename TensorC>
CUTE_DEVICE void gemm_update_16x16(const unsigned lane_id,
                                   const TensorA& a_smem, const TensorB& b_smem,
                                   TensorC& c_rmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(a_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(b_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(c_rmem) == _1{});

  CUTE_STATIC_ASSERT_V(size<0>(a_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(a_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(b_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(b_smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(c_rmem) == _8{});

  CUTE_STATIC_ASSERT(
      is_same_v<typename TensorA::value_type, typename TensorB::value_type>);
  CUTE_STATIC_ASSERT(
      is_same_v<typename TensorA::value_type, typename TensorC::value_type>);

  using T = typename TensorA::value_type;

  const auto row_in_a = lane_id % 16;
  const auto first_col_in_a = lane_id / 16;
  const auto first_row_in_b = first_col_in_a;

  const bool offset_in_c_vector = first_col_in_a;

  T frag_a[8], frag_b[8];

  CUTE_UNROLL
  for (int col_group = 0; col_group < 8; ++col_group) {
    frag_a[col_group] = a_smem(row_in_a, first_col_in_a + col_group * 2);
  }

  CUTE_UNROLL
  for (int col_group = 0; col_group < 8; ++col_group) {
    T val_c_vector[2] = {0, 0};
    CUTE_UNROLL
    for (int row_group = 0; row_group < 8; ++row_group) {
      frag_b[row_group] =
          b_smem(first_row_in_b + row_group * 2, 0 + col_group * 2);
    }
    CUTE_UNROLL
    for (int reduction_group = 0; reduction_group < 8; ++reduction_group) {
      val_c_vector[0] += frag_a[reduction_group] * frag_b[reduction_group];
    }
    CUTE_UNROLL
    for (int row_group = 0; row_group < 8; ++row_group) {
      frag_b[row_group] =
          b_smem(first_row_in_b + row_group * 2, 1 + col_group * 2);
    }
    CUTE_UNROLL
    for (int reduction_group = 0; reduction_group < 8; ++reduction_group) {
      val_c_vector[1] += frag_a[reduction_group] * frag_b[reduction_group];
    }
    T val_c = val_c_vector[offset_in_c_vector];
    val_c += __shfl_xor_sync(0xFFFFFFFF, val_c_vector[!offset_in_c_vector], 16);
    c_rmem(col_group) -= val_c;
  }
}

template <typename TensorSmem, typename TensorRmem>
CUTE_DEVICE void copy_16x16(const unsigned lane_id, const TensorSmem& smem,
                            TensorRmem& rmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(rmem) == _1{});

  CUTE_STATIC_ASSERT_V(size<0>(smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<1>(smem) == _16{});
  CUTE_STATIC_ASSERT_V(size<0>(rmem) == _8{});

  static_assert(std::is_same_v<typename TensorSmem::value_type,
                               typename TensorRmem::value_type>);

  CUTE_UNROLL
  for (int i = 0; i < 16 / 2; ++i) {
    rmem[i] = smem[lane_id + i * 32];
  }
}

template <bool enable_static_pivoting, class TensorSmem, class TensorGmem>
CUTE_DEVICE void lu_64x64_128_threads(
    const unsigned thread_idx, const int bound_m, const int bound_n,
    TensorSmem& smem, TensorGmem& gmem,
    cuda::atomic<int>* const pivot_count_ptr) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorSmem::value_type,
                               typename TensorGmem::value_type>);

  const auto warp_id = thread_idx / 32;
  const auto lane_id = thread_idx % 32;

  using T = typename TensorSmem::value_type;

  auto rmem = make_tensor<T>(make_shape(_8{}));

  constexpr auto tiler = make_shape(_16{}, _16{});

  const auto local_pred_row = [&](const auto& row_block) {
    return [=](auto const& coord) { return row_block * 16 + coord < bound_m; };
  };

  const auto local_pred_col = [&](const auto& col_block) {
    return [=](auto const& coord) { return col_block * 16 + coord < bound_n; };
  };

  const auto local_gmem = [&](const auto& row_block, const auto& col_block) {
    return local_tile(gmem, tiler, make_coord(row_block, col_block));
  };

  const auto local_smem = [&](const auto& row_block, const auto& col_block) {
    return local_tile(smem, tiler, make_coord(row_block, col_block));
  };

  if (warp_id == 0) {
    copy_16x16(lane_id, local_smem(0, 0), rmem);
    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(0),
                                     local_pred_col(0), local_gmem(0, 0),
                                     local_smem(0, 0), rmem, pivot_count_ptr);

    __syncthreads();
    // 1: (0, 0) is ready

    copy_16x16(lane_id, local_smem(0, 2), rmem);
    lx_solve_16x16(lane_id, local_pred_col(2), local_smem(0, 0),
                   local_gmem(0, 2), local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready

    copy_16x16(lane_id, local_smem(2, 1), rmem);
    gemm_update_16x16(lane_id, local_smem(2, 0), local_smem(0, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready

    xu_solve_16x16(lane_id, local_pred_row(2), local_smem(1, 1),
                   local_gmem(2, 1), local_smem(2, 1), rmem);

    copy_16x16(lane_id, local_smem(2, 2), rmem);
    gemm_update_16x16(lane_id, local_smem(2, 0), local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready

    gemm_update_16x16(lane_id, local_smem(2, 1), local_smem(1, 2), rmem);

    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(2),
                                     local_pred_col(2), local_gmem(2, 2),
                                     local_smem(2, 2), rmem, pivot_count_ptr);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready
    // 6: (2, 3), (3, 2) are ready
  } else if (warp_id == 1) {
    copy_16x16(lane_id, local_smem(1, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    xu_solve_16x16(lane_id, local_pred_row(1), local_smem(0, 0),
                   local_gmem(1, 0), local_smem(1, 0), rmem);

    copy_16x16(lane_id, local_smem(3, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready

    xu_solve_16x16(lane_id, local_pred_row(3), local_smem(0, 0),
                   local_gmem(3, 0), local_smem(3, 0), rmem);

    copy_16x16(lane_id, local_smem(1, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready

    gemm_update_16x16(lane_id, local_smem(1, 0), local_smem(0, 2), rmem);
    lx_solve_16x16(lane_id, local_pred_col(2), local_smem(1, 1),
                   local_gmem(1, 2), local_smem(1, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready

    copy_16x16(lane_id, local_smem(3, 2), rmem);
    gemm_update_16x16(lane_id, local_smem(3, 0), local_smem(0, 2), rmem);
    gemm_update_16x16(lane_id, local_smem(3, 1), local_smem(1, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready

    xu_solve_16x16(lane_id, local_pred_row(3), local_smem(2, 2),
                   local_gmem(3, 2), local_smem(3, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready
    // 6: (2, 3), (3, 2) are ready
  } else if (warp_id == 2) {
    copy_16x16(lane_id, local_smem(0, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    lx_solve_16x16(lane_id, local_pred_col(1), local_smem(0, 0),
                   local_gmem(0, 1), local_smem(0, 1), rmem);
    copy_16x16(lane_id, local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready

    // solve (0, 3)
    lx_solve_16x16(lane_id, local_pred_col(3), local_smem(0, 0),
                   local_gmem(0, 3), local_smem(0, 3), rmem);

    copy_16x16(lane_id, local_smem(3, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready

    gemm_update_16x16(lane_id, local_smem(3, 0), local_smem(0, 1), rmem);

    xu_solve_16x16(lane_id, local_pred_row(3), local_smem(1, 1),
                   local_gmem(3, 1), local_smem(3, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready

    copy_16x16(lane_id, local_smem(2, 3), rmem);
    gemm_update_16x16(lane_id, local_smem(2, 0), local_smem(0, 3), rmem);
    gemm_update_16x16(lane_id, local_smem(2, 1), local_smem(1, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready

    lx_solve_16x16(lane_id, local_pred_col(3), local_smem(2, 2),
                   local_gmem(2, 3), local_smem(2, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready
    // 6: (2, 3), (3, 2) are ready
  } else {
    copy_16x16(lane_id, local_smem(2, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    xu_solve_16x16(lane_id, local_pred_row(2), local_smem(0, 0),
                   local_gmem(2, 0), local_smem(2, 0), rmem);
    copy_16x16(lane_id, local_smem(1, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready

    gemm_update_16x16(lane_id, local_smem(1, 0), local_smem(0, 1), rmem);
    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(1),
                                     local_pred_col(1), local_gmem(1, 1),
                                     local_smem(1, 1), rmem, pivot_count_ptr);

    // tell other warps that (1, 1) is ready
    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready

    copy_16x16(lane_id, local_smem(1, 3), rmem);
    gemm_update_16x16(lane_id, local_smem(1, 0), local_smem(0, 3), rmem);

    lx_solve_16x16(lane_id, local_pred_col(3), local_smem(1, 1),
                   local_gmem(1, 3), local_smem(1, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    copy_16x16(lane_id, local_smem(3, 3), rmem);
    gemm_update_16x16(lane_id, local_smem(3, 0), local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready
    gemm_update_16x16(lane_id, local_smem(3, 1), local_smem(1, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (0, 1), (0, 2) are ready
    // 3: (0, 3), (3, 0), (1, 1) are ready
    // 4: (1, 2), (1, 3), (2, 1), (3, 1) are ready
    // 5: (2, 2) is ready
    // 6: (2, 3), (3, 2) are ready
    gemm_update_16x16(lane_id, local_smem(3, 2), local_smem(2, 3), rmem);

    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(3),
                                     local_pred_col(3), local_gmem(3, 3),
                                     local_smem(3, 3), rmem, pivot_count_ptr);
  }
}

template <bool enable_static_pivoting, class TensorSmem, class TensorGmem>
CUTE_DEVICE void lu_64x64_256_threads(
    const unsigned thread_idx, const int bound_m, const int bound_n,
    TensorSmem& smem, TensorGmem& gmem,
    cuda::atomic<int>* const pivot_count_ptr) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorSmem::value_type,
                               typename TensorGmem::value_type>);

  const auto warp_id = thread_idx / 32;
  const auto lane_id = thread_idx % 32;

  using T = typename TensorSmem::value_type;

  auto rmem = make_tensor<T>(make_shape(_8{}));

  constexpr auto tiler = make_shape(_16{}, _16{});

  const auto local_pred_row = [&](const auto& row_block) {
    return [=](auto const& coord) { return row_block * 16 + coord < bound_m; };
  };

  const auto local_pred_col = [&](const auto& col_block) {
    return [=](auto const& coord) { return col_block * 16 + coord < bound_n; };
  };

  const auto local_gmem = [&](const auto& row_block, const auto& col_block) {
    return local_tile(gmem, tiler, make_coord(row_block, col_block));
  };

  const auto local_smem = [&](const auto& row_block, const auto& col_block) {
    return local_tile(smem, tiler, make_coord(row_block, col_block));
  };

  if (warp_id == 0) {
    copy_16x16(lane_id, local_smem(0, 0), rmem);
    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(0),
                                     local_pred_col(0), local_gmem(0, 0),
                                     local_smem(0, 0), rmem, pivot_count_ptr);

    __syncthreads();
    // 1: (0, 0) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(2, 1), rmem);
    gemm_update_16x16(lane_id, local_smem(2, 0), local_smem(0, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    xu_solve_16x16(lane_id, local_pred_row(2), local_smem(1, 1),
                   local_gmem(2, 1), local_smem(2, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready
  } else if (warp_id == 1) {
    copy_16x16(lane_id, local_smem(1, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    xu_solve_16x16(lane_id, local_pred_row(1), local_smem(0, 0),
                   local_gmem(1, 0), local_smem(1, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(1, 2), rmem);
    gemm_update_16x16(lane_id, local_smem(1, 0), local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    lx_solve_16x16(lane_id, local_pred_col(2), local_smem(1, 1),
                   local_gmem(1, 2), local_smem(1, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready
  } else if (warp_id == 2) {
    copy_16x16(lane_id, local_smem(0, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    lx_solve_16x16(lane_id, local_pred_col(1), local_smem(0, 0),
                   local_gmem(0, 1), local_smem(0, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(3, 1), rmem);
    gemm_update_16x16(lane_id, local_smem(3, 0), local_smem(0, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    xu_solve_16x16(lane_id, local_pred_row(3), local_smem(1, 1),
                   local_gmem(3, 1), local_smem(3, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready
  } else if (warp_id == 3) {
    copy_16x16(lane_id, local_smem(2, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    xu_solve_16x16(lane_id, local_pred_row(2), local_smem(0, 0),
                   local_gmem(2, 0), local_smem(2, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(1, 3), rmem);
    gemm_update_16x16(lane_id, local_smem(1, 0), local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    lx_solve_16x16(lane_id, local_pred_col(3), local_smem(1, 1),
                   local_gmem(1, 3), local_smem(1, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready
  } else if (warp_id == 4) {
    copy_16x16(lane_id, local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    lx_solve_16x16(lane_id, local_pred_col(2), local_smem(0, 0),
                   local_gmem(0, 2), local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(2, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    gemm_update_16x16(lane_id, local_smem(2, 0), local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    gemm_update_16x16(lane_id, local_smem(2, 1), local_smem(1, 2), rmem);
    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(2),
                                     local_pred_col(2), local_gmem(2, 2),
                                     local_smem(2, 2), rmem, pivot_count_ptr);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready

  } else if (warp_id == 5) {
    copy_16x16(lane_id, local_smem(3, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    xu_solve_16x16(lane_id, local_pred_row(3), local_smem(0, 0),
                   local_gmem(3, 0), local_smem(3, 0), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(3, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    gemm_update_16x16(lane_id, local_smem(3, 0), local_smem(0, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    gemm_update_16x16(lane_id, local_smem(3, 1), local_smem(1, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    xu_solve_16x16(lane_id, local_pred_row(3), local_smem(2, 2),
                   local_gmem(3, 2), local_smem(3, 2), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready
  } else if (warp_id == 6) {
    copy_16x16(lane_id, local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    lx_solve_16x16(lane_id, local_pred_col(3), local_smem(0, 0),
                   local_gmem(0, 3), local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    copy_16x16(lane_id, local_smem(2, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    gemm_update_16x16(lane_id, local_smem(2, 0), local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    gemm_update_16x16(lane_id, local_smem(2, 1), local_smem(1, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    lx_solve_16x16(lane_id, local_pred_col(3), local_smem(2, 2),
                   local_gmem(2, 3), local_smem(2, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready
  } else if (warp_id == 7) {
    copy_16x16(lane_id, local_smem(1, 1), rmem);

    __syncthreads();
    // 1: (0, 0) is ready

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready

    gemm_update_16x16(lane_id, local_smem(1, 0), local_smem(0, 1), rmem);
    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(1),
                                     local_pred_col(1), local_gmem(1, 1),
                                     local_smem(1, 1), rmem, pivot_count_ptr);
    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready

    copy_16x16(lane_id, local_smem(3, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready

    gemm_update_16x16(lane_id, local_smem(3, 0), local_smem(0, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready

    gemm_update_16x16(lane_id, local_smem(3, 1), local_smem(1, 3), rmem);

    __syncthreads();
    // 1: (0, 0) is ready
    // 2: (1, 0), (2, 0), (3, 0), (0, 1), (0, 2), (0, 3) are ready
    // 3: (1, 1) is ready
    // 4: (2, 1), (3, 1), (1, 2), (1, 3) are ready
    // 5: (2, 2) is ready
    // 6: (3, 2) (2, 3) are ready

    gemm_update_16x16(lane_id, local_smem(3, 2), local_smem(2, 3), rmem);
    lu_16x16<enable_static_pivoting>(lane_id, local_pred_row(3),
                                     local_pred_col(3), local_gmem(3, 3),
                                     local_smem(3, 3), rmem, pivot_count_ptr);
  }
}

template <unsigned threads, bool enable_static_pivoting, class... Args>
CUTE_DEVICE void lu_64x64(Args&&... args) {
  CUTE_STATIC_ASSERT(threads == 128 || threads == 256);
  if constexpr (threads == 128) {
    lu_64x64_128_threads<enable_static_pivoting>(std::forward<Args>(args)...);
  } else if constexpr (threads == 256) {
    lu_64x64_256_threads<enable_static_pivoting>(std::forward<Args>(args)...);
  }
}

template <bool enable_static_pivoting, class TensorSmem, class TensorGmem>
CUTE_DEVICE void lu_64x64_naive_256_threads(
    const unsigned thread_idx, const int bound_m, const int bound_n,
    TensorSmem& smem, TensorGmem& gmem,
    cuda::atomic<int>* const pivot_count_ptr,
    const typename TensorSmem::value_type criterion) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(smem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorSmem::value_type,
                               typename TensorGmem::value_type>);

  using T = typename TensorSmem::value_type;

  const auto thread_row = thread_idx % 16;
  const auto thread_col = thread_idx / 16;

  CUTE_UNROLL
  for (unsigned diag_idx = 0; diag_idx < 64; ++diag_idx) {
    const auto block_size = 4 - diag_idx / 16;
    // block size is up to 4
    T l[4], u[4];
    bool pred_row[4] = {false, false, false, false};
    bool pred_col[4] = {false, false, false, false};

    if (1 + diag_idx + thread_idx < 64) {
      smem(1 + diag_idx + thread_idx, diag_idx) /= smem(diag_idx, diag_idx);
    }
    __syncthreads();

    CUTE_UNROLL
    for (unsigned i = 0; i < block_size; ++i) {
      if (1 + diag_idx + i * 16 + thread_row < 64) {
        l[i] = smem(1 + diag_idx + i * 16 + thread_row, diag_idx);
        pred_row[i] = true;
      }
      if (1 + diag_idx + i * 16 + thread_col < 64) {
        u[i] = smem(diag_idx, 1 + diag_idx + i * 16 + thread_col);
        pred_col[i] = true;
      }
    }

    CUTE_UNROLL
    for (unsigned row = 0; row < block_size; ++row) {
      CUTE_UNROLL
      for (unsigned col = 0; col < block_size; ++col) {
        if (pred_row[row] && pred_col[col]) {
          auto value = smem(1 + diag_idx + row * 16 + thread_row,
                            1 + diag_idx + col * 16 + thread_col);
          value -= l[row] * u[col];
          if constexpr (enable_static_pivoting) {
            if (thread_idx == 0 && row == 0 && col == 0) {
              if (std::abs(value) < criterion) {
                if (value < 0) {
                  value = -criterion;
                } else {
                  value = criterion;
                }
                pivot_count_ptr->fetch_add(
                    1, cuda::memory_order::memory_order_relaxed);
              }
            }
          }
          smem(1 + diag_idx + row * 16 + thread_row,
               1 + diag_idx + col * 16 + thread_col) = value;
        }
      }
    }

    __syncthreads();
  }
}

template <unsigned threads, bool enable_static_pivoting, class... Args>
CUTE_DEVICE void lu_64x64_naive(Args&&... args) {
  CUTE_STATIC_ASSERT(threads == 256);
  if constexpr (threads == 256) {
    lu_64x64_naive_256_threads<enable_static_pivoting>(
        std::forward<Args>(args)...);
  }
}

template <class TensorUSmem, class TensorXSmem, class TensorXGmem>
CUTE_DEVICE void xu_solve_64x64_128_threads(const unsigned thread_idx,
                                            const int bound,
                                            const TensorUSmem& u_smem,
                                            const TensorXSmem& x_smem,
                                            TensorXGmem& x_gmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(u_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_gmem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(u_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(u_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorUSmem::value_type,
                               typename TensorXSmem::value_type>);
  CUTE_STATIC_ASSERT(is_same_v<typename TensorXSmem::value_type,
                               typename TensorXGmem::value_type>);

  using T = typename TensorUSmem::value_type;

  const unsigned row = thread_idx / 2;
  const unsigned first_col = thread_idx % 2;
  const bool is_even_col = first_col == 0;

  T x_local[32];

  CUTE_UNROLL
  for (int group = 0; group < 32; ++group) {
    x_local[group] = x_smem(row, first_col + group * 2);
  }

  CUTE_UNROLL
  for (int solve_group = 0; solve_group < 32; ++solve_group) {
    {
      if (is_even_col) {
        x_local[solve_group] /=
            u_smem(solve_group * 2 + 0, solve_group * 2 + 0);
      }

      T pivot = __shfl_up_sync(0xFFFFFFFF, x_local[solve_group], 1);
      if (is_even_col) {
        pivot = x_local[solve_group];
      }

      if (not is_even_col) {
        x_local[solve_group] -=
            pivot * u_smem(solve_group * 2, solve_group * 2 + 1);
      }

      CUTE_UNROLL
      for (int update_group = solve_group + 1; update_group < 32;
           ++update_group) {
        x_local[update_group] -=
            pivot * u_smem(solve_group * 2 + 0, first_col + update_group * 2);
      }
    }
    {
      if (not is_even_col) {
        x_local[solve_group] /=
            u_smem(solve_group * 2 + 1, solve_group * 2 + 1);
      }

      T pivot = __shfl_down_sync(0xFFFFFFFF, x_local[solve_group], 1);
      if (not is_even_col) {
        pivot = x_local[solve_group];
      }

      CUTE_UNROLL
      for (int update_group = solve_group + 1; update_group < 32;
           ++update_group) {
        x_local[update_group] -=
            pivot * u_smem(solve_group * 2 + 1, first_col + update_group * 2);
      }
    }
    if (row < bound) {
      x_gmem(row, first_col + solve_group * 2) = x_local[solve_group];
    }
  }
}

template <unsigned threads, class TensorUSmem, class TensorXSmem,
          class TensorXGmem>
CUTE_DEVICE void xu_solve_64x64_n_threads(const unsigned thread_idx,
                                          const int bound,
                                          const TensorUSmem& u_smem,
                                          const TensorXSmem& x_smem,
                                          TensorXGmem& x_gmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(u_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_gmem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(u_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(u_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorUSmem::value_type,
                               typename TensorXSmem::value_type>);
  CUTE_STATIC_ASSERT(is_same_v<typename TensorXSmem::value_type,
                               typename TensorXGmem::value_type>);

  using T = typename TensorUSmem::value_type;

  CUTE_STATIC_ASSERT(threads % 64 == 0);
  CUTE_STATIC_ASSERT(threads > 128);
  CUTE_STATIC_ASSERT(threads <= 1024);

  constexpr static unsigned threads_in_one_row = threads / 64;
  constexpr static unsigned threads_iterates = 64 / threads_in_one_row;

  CUTE_STATIC_ASSERT(64 % threads_in_one_row == 0);

  const unsigned row = thread_idx / threads_in_one_row;
  const unsigned first_col = thread_idx % threads_in_one_row;

  T x_local[threads_iterates];

  CUTE_UNROLL
  for (int group = 0; group < threads_iterates; ++group) {
    x_local[group] = x_smem(row, first_col + group * threads_in_one_row);
  }

  CUTE_UNROLL
  for (int solve_group = 0; solve_group < threads_iterates; ++solve_group) {
    CUTE_UNROLL
    for (int solve_col = 0; solve_col < threads_in_one_row; ++solve_col) {
      if (first_col == solve_col) {
        x_local[solve_group] /=
            u_smem(solve_col + solve_group * threads_in_one_row,
                   solve_col + solve_group * threads_in_one_row);
        x_smem(row, solve_col + solve_group * threads_in_one_row) =
            x_local[solve_group];
      }
      __syncwarp();
      const T pivot = x_smem(row, solve_col + solve_group * threads_in_one_row);
      if (first_col > solve_col) {
        x_local[solve_group] -=
            pivot * u_smem(solve_col + solve_group * threads_in_one_row,
                           first_col + solve_group * threads_in_one_row);
      }
      CUTE_UNROLL
      for (int update_group = solve_group + 1; update_group < threads_iterates;
           ++update_group) {
        x_local[update_group] -=
            pivot * u_smem(solve_col + solve_group * threads_in_one_row,
                           first_col + update_group * threads_in_one_row);
      }
    }
    if (row < bound) {
      x_gmem(row, first_col + solve_group * threads_in_one_row) =
          x_local[solve_group];
    }
  }
}

template <unsigned threads, class... Args>
CUTE_DEVICE void xu_solve_64x64(Args&&... args) {
  if constexpr (threads == 128) {
    xu_solve_64x64_128_threads(cuda::std::forward<Args>(args)...);
  } else {
    xu_solve_64x64_n_threads<threads>(cuda::std::forward<Args>(args)...);
  }
}

template <class TensorLSmem, class TensorXSmem, class TensorXGmem>
CUTE_DEVICE void lx_solve_64x64_128_threads(const unsigned thread_idx,
                                            const int bound,
                                            const TensorLSmem& l_smem,
                                            const TensorXSmem& x_smem,
                                            TensorXGmem& x_gmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(l_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_gmem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(l_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(l_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorLSmem::value_type,
                               typename TensorXSmem::value_type>);
  CUTE_STATIC_ASSERT(is_same_v<typename TensorXSmem::value_type,
                               typename TensorXGmem::value_type>);

  using T = typename TensorLSmem::value_type;

  const unsigned col = thread_idx / 2;
  const unsigned first_row = thread_idx % 2;
  const bool is_even_row = first_row == 0;

  T x_local[32];

  CUTE_UNROLL
  for (int group = 0; group < 32; ++group) {
    x_local[group] = x_smem(first_row + group * 2, col);
  }

  CUTE_UNROLL
  for (int solve_group = 0; solve_group < 32; ++solve_group) {
    {
      T pivot = __shfl_up_sync(0xFFFFFFFF, x_local[solve_group], 1);
      if (is_even_row) {
        pivot = x_local[solve_group];
      }

      if (not is_even_row) {
        x_local[solve_group] -=
            pivot * l_smem(solve_group * 2 + 1, solve_group * 2 + 0);
      }

      CUTE_UNROLL
      for (int update_group = solve_group + 1; update_group < 32;
           ++update_group) {
        x_local[update_group] -=
            pivot * l_smem(first_row + update_group * 2, solve_group * 2 + 0);
      }
    }
    {
      T pivot = __shfl_down_sync(0xFFFFFFFF, x_local[solve_group], 1);
      if (not is_even_row) {
        pivot = x_local[solve_group];
      }

      CUTE_UNROLL
      for (int update_group = solve_group + 1; update_group < 32;
           ++update_group) {
        x_local[update_group] -=
            pivot * l_smem(first_row + update_group * 2, solve_group * 2 + 1);
      }
    }
    if (col < bound) {
      x_gmem(first_row + solve_group * 2, col) = x_local[solve_group];
    }
  }
}

template <unsigned threads, class TensorLSmem, class TensorXSmem,
          class TensorXGmem>
CUTE_DEVICE void lx_solve_64x64_n_threads(const unsigned thread_idx,
                                          const int bound,
                                          const TensorLSmem& l_smem,
                                          const TensorXSmem& x_smem,
                                          TensorXGmem& x_gmem) {
  using namespace cute;

  CUTE_STATIC_ASSERT_V(rank(l_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_smem) == _2{});
  CUTE_STATIC_ASSERT_V(rank(x_gmem) == _2{});

  CUTE_STATIC_ASSERT_V(size<0>(l_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(l_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_smem) == _64{});
  CUTE_STATIC_ASSERT_V(size<0>(x_gmem) == _64{});
  CUTE_STATIC_ASSERT_V(size<1>(x_gmem) == _64{});

  CUTE_STATIC_ASSERT(is_same_v<typename TensorLSmem::value_type,
                               typename TensorXSmem::value_type>);
  CUTE_STATIC_ASSERT(is_same_v<typename TensorXSmem::value_type,
                               typename TensorXGmem::value_type>);

  CUTE_STATIC_ASSERT(threads % 64 == 0);
  CUTE_STATIC_ASSERT(threads > 128);
  CUTE_STATIC_ASSERT(threads <= 1024);

  constexpr static unsigned threads_in_one_col = threads / 64;
  constexpr static unsigned threads_iterates = 64 / threads_in_one_col;

  CUTE_STATIC_ASSERT(64 % threads_in_one_col == 0);

  using T = typename TensorLSmem::value_type;

  const unsigned col = thread_idx / threads_in_one_col;
  const unsigned first_row = thread_idx % threads_in_one_col;

  T x_local[threads_iterates];

  CUTE_UNROLL
  for (int group = 0; group < threads_iterates; ++group) {
    x_local[group] = x_smem(first_row + group * threads_in_one_col, col);
  }

  CUTE_UNROLL
  for (int solve_group = 0; solve_group < threads_iterates; ++solve_group) {
    CUTE_UNROLL
    for (int solve_row = 0; solve_row < threads_in_one_col; ++solve_row) {
      if (first_row == solve_row) {
        x_smem(solve_row + solve_group * threads_in_one_col, col) =
            x_local[solve_group];
      }
      __syncwarp();
      const T pivot = x_smem(solve_row + solve_group * threads_in_one_col, col);
      if (first_row > solve_row) {
        x_local[solve_group] -=
            pivot * l_smem(first_row + solve_group * threads_in_one_col,
                           solve_row + solve_group * threads_in_one_col);
      }
      CUTE_UNROLL
      for (int update_group = solve_group + 1; update_group < threads_iterates;
           ++update_group) {
        x_local[update_group] -=
            pivot * l_smem(first_row + update_group * threads_in_one_col,
                           solve_row + solve_group * threads_in_one_col);
      }
    }
    if (col < bound) {
      x_gmem(first_row + solve_group * threads_in_one_col, col) =
          x_local[solve_group];
    }
  }
}

template <unsigned threads, class... Args>
CUTE_HOST_DEVICE void lx_solve_64x64(Args&&... args) {
  if constexpr (threads == 128) {
    lx_solve_64x64_128_threads(cuda::std::forward<Args>(args)...);
  } else {
    lx_solve_64x64_n_threads<threads>(cuda::std::forward<Args>(args)...);
  }
}

template <bool enable_static_pivoting, class ShapeType, class T, int Stages,
          class TileShape, class GmemTiledCopyA, class SmemCopyAtomA,
          class SmemLayoutA, class GmemTiledCopyB, class SmemCopyAtomB,
          class SmemLayoutB, class SmemLayoutC, class GmemTiledCopyC,
          class Smem, class TiledMma, int threads>
__global__ void __launch_bounds__(threads)
    getrf_static_pivot_kernel(ShapeType shape_M, T* A, ShapeType ldA,
                              cuda::atomic<int>* const task_index_ptr,
                              cuda::atomic<bool>* const task_table_ptr,
                              cuda::atomic<int>* const pivot_count_ptr,
                              const T criterion, int64_t* const cycles) {
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
  using namespace cute;

  int thread_idx = static_cast<int>(threadIdx.x);

  const auto task_index = [&] {
    extern __shared__ int task_index[];
    if (thread_idx == 0) {
      *task_index = task_index_ptr->fetch_add(1, cuda::memory_order_relaxed);
    }
    __syncthreads();
    return *task_index;
  }();

  constexpr static auto BLK_M = size<0>(TileShape{});
  constexpr static auto BLK_N = size<1>(TileShape{});
  constexpr static auto BLK_K = size<2>(TileShape{});
  static_assert(BLK_M == BLK_N);

  constexpr static auto TILE_NUM_IN_BLOCK = BLK_M / BLK_K;
  static_assert(BLK_M % BLK_K == 0);
  static_assert(BLK_M >= BLK_K);

  const int BLOCK_NUM = ceil_div(shape_M, BLK_M);

  int record_cycle_step = 0;
  const auto record_cycle = [&] {
    if (thread_idx == 0) {
      cycles[task_index * (2 * (BLOCK_NUM - 1) + 4) + record_cycle_step] =
          clock64();
    }
    ++record_cycle_step;
  };

  // start
  record_cycle();

  const auto blockIdx_ = index_to_coord(task_index, BLOCK_NUM);
  const auto blockIdx_x = get<0>(blockIdx_);
  const auto blockIdx_y = get<1>(blockIdx_);

  Tensor task_table = make_tensor(make_gmem_ptr(task_table_ptr),
                                  make_shape(BLOCK_NUM, BLOCK_NUM));

  const auto dA = make_stride(_1{}, ldA);  // (dM, dK)
  const auto dB = make_stride(ldA, _1{});  // (dN, dK)
  const auto dC = make_stride(_1{}, ldA);  // (dM, dN)

  const auto shape_MNK =
      make_shape(shape_M, shape_M, BLK_M * min(blockIdx_x, blockIdx_y));

  // Preconditions
  CUTE_STATIC_ASSERT_V(rank(shape_MNK) == Int<3>{});    // (M, N, K)
  CUTE_STATIC_ASSERT_V(rank(TileShape{}) == Int<3>{});  // (BLK_M, BLK_N, BLK_K)

  TiledMma mma{};
  CUTE_STATIC_ASSERT(size(mma) == threads);

  static_assert(is_static<SmemLayoutA>::value);
  static_assert(is_static<SmemLayoutB>::value);
  static_assert(is_static<SmemLayoutC>::value);

  CUTE_STATIC_ASSERT_V(size<0>(SmemLayoutA{}) ==
                       size<0>(TileShape{}));  // BLK_M
  CUTE_STATIC_ASSERT_V(size<0>(SmemLayoutC{}) ==
                       size<0>(TileShape{}));  // BLK_M
  CUTE_STATIC_ASSERT_V(size<0>(SmemLayoutB{}) ==
                       size<1>(TileShape{}));  // BLK_N
  CUTE_STATIC_ASSERT_V(size<1>(SmemLayoutC{}) ==
                       size<1>(TileShape{}));  // BLK_N
  CUTE_STATIC_ASSERT_V(size<1>(SmemLayoutA{}) ==
                       size<2>(TileShape{}));  // BLK_K
  CUTE_STATIC_ASSERT_V(size<1>(SmemLayoutB{}) ==
                       size<2>(TileShape{}));  // BLK_K

  CUTE_STATIC_ASSERT_V(
      congruent(select<0, 2>(shape_MNK), dA));  // dA strides for shape MK
  CUTE_STATIC_ASSERT_V(
      congruent(select<1, 2>(shape_MNK), dB));  // dB strides for shape NK
  CUTE_STATIC_ASSERT_V(
      congruent(select<0, 1>(shape_MNK), dC));  // dC strides for shape MN

  //
  // Full and Tiled Tensors
  //

  // Represent the full tensors
  Tensor mA =
      make_tensor(make_gmem_ptr(A), select<0, 2>(shape_MNK), dA);  // (M,K)
  Tensor mB =
      make_tensor(make_gmem_ptr(A), select<1, 2>(shape_MNK), dB);  // (N,K)
  Tensor mC =
      make_tensor(make_gmem_ptr(A), select<0, 1>(shape_MNK), dC);  // (M,N)

  // Get the appropriate blocks for this thread block
  auto cta_coord = make_coord(blockIdx_x, blockIdx_y, _);  // (m,n,k)
  Tensor gA = local_tile(mA, TileShape{}, cta_coord,
                         Step<_1, X, _1>{});  // (BLK_M,BLK_K,k)
  Tensor gB = local_tile(mB, TileShape{}, cta_coord,
                         Step<X, _1, _1>{});  // (BLK_N,BLK_K,k)
  Tensor gC = local_tile(mC, TileShape{}, cta_coord,
                         Step<_1, _1, X>{});  // (BLK_M,BLK_N)

  // Allocate the tiled_mma and the accumulators for the (M,N) blk_shape
  TiledMma tiled_mma;
  Tensor accum = partition_fragment_C(
      tiled_mma, take<0, 2>(TileShape{}));  // (MMA,MMA_M,MMA_N)

  auto k_tile_iter = cute::make_coord_iterator(shape<2>(gA));
  int k_tile_count = size<2>(gA);

  extern __shared__ char shared_memory[];
  Smem& smem = *reinterpret_cast<Smem*>(shared_memory);

  Tensor sA = make_tensor(make_smem_ptr(smem.update.smem_a.data()),
                          SmemLayoutA{});  // (BLK_M,BLK_K,PIPE)
  Tensor sB = make_tensor(make_smem_ptr(smem.update.smem_b.data()),
                          SmemLayoutB{});  // (BLK_N,BLK_K,PIPE)

  CUTE_STATIC_ASSERT_V(size<0>(gA) == size<0>(sA));    // BLK_M
  CUTE_STATIC_ASSERT_V(size<1>(gA) == size<1>(sA));    // BLK_K
  CUTE_STATIC_ASSERT_V(size<0>(gB) == size<0>(sB));    // BLK_N
  CUTE_STATIC_ASSERT_V(size<1>(gB) == size<1>(sB));    // BLK_K
  CUTE_STATIC_ASSERT_V(size<1>(sA) == size<1>(sB));    // BLK_K
  CUTE_STATIC_ASSERT_V(Int<Stages>{} == size<2>(sA));  // PIPE
  CUTE_STATIC_ASSERT_V(Int<Stages>{} == size<2>(sB));  // PIPE

  // Compute tile residues for predication
  const int LEGAL_BLK_M = min(BLK_M, shape_M - BLK_M * blockIdx_x);
  const int LEGAL_BLK_N = min(BLK_N, shape_M - BLK_M * blockIdx_y);
  const int LEGAL_BLK_K = get<2>(shape_MNK) - size<1>(gA) * size<2>(gA);
  const auto residue_mnk = make_shape(LEGAL_BLK_M, LEGAL_BLK_N, LEGAL_BLK_K);

  //
  // MMA Atom partitioning
  //

  // Tile MMA compute thread partitions and allocate accumulators
  auto thr_mma = tiled_mma.get_thread_slice(thread_idx);
  Tensor tCrA = thr_mma.partition_fragment_A(sA(_, _, 0));  // (MMA,MMA_M,MMA_K)
  Tensor tCrB = thr_mma.partition_fragment_B(sB(_, _, 0));  // (MMA,MMA_N,MMA_K)

  CUTE_STATIC_ASSERT_V(size<1>(tCrA) == size<1>(accum));  // MMA_M
  CUTE_STATIC_ASSERT_V(size<1>(tCrB) == size<2>(accum));  // MMA_N
  CUTE_STATIC_ASSERT_V(size<2>(tCrA) == size<2>(tCrB));   // MMA_K

  const Tensor cC =
      make_identity_tensor(shape(gC));  // (BLK_M,BLK_N) -> (blk_m, blk_n)
  const Tensor tSR_cC = thr_mma.partition_C(
      cC);  // ((Atom, AtomNum), ATOM_M, ATOM_N, TILE_M, TILE_N)

  auto tCpC = [&](auto const&... coords) {
    return elem_less(tSR_cC(coords...), select<0, 1>(residue_mnk));
  };

  Tensor tCgC = thr_mma.partition_C(gC);  // (MMA,MMA_M,MMA_N)

  CUTLASS_PRAGMA_UNROLL
  for (int i = 0; i < size(accum); ++i) {
    if (tCpC(i)) {
      accum(i) = -tCgC(i);
    }
  }

  if (blockIdx_x != 0 && blockIdx_y != 0) {
    // Shift tensor so residue_k is at origin (Can't read any k_coord <
    // residue_k) This aligns the tensor with BLK_K for all but the 0th k_tile
    gA = cute::domain_offset(make_coord(0, get<2>(residue_mnk), 0), gA);
    gB = cute::domain_offset(make_coord(0, get<2>(residue_mnk), 0), gB);

    // Partition the copying of A and B tiles across the threads
    GmemTiledCopyA gmem_tiled_copy_A;
    GmemTiledCopyB gmem_tiled_copy_B;
    auto gmem_thr_copy_A = gmem_tiled_copy_A.get_slice(thread_idx);
    auto gmem_thr_copy_B = gmem_tiled_copy_B.get_slice(thread_idx);

    Tensor tAgA = gmem_thr_copy_A.partition_S(gA);  // (ACPY,ACPY_M,ACPY_K,k)
    Tensor tAsA = gmem_thr_copy_A.partition_D(sA);  // (ACPY,ACPY_M,ACPY_K,PIPE)
    Tensor tBgB = gmem_thr_copy_B.partition_S(gB);  // (BCPY,BCPY_N,BCPY_K,k)
    Tensor tBsB = gmem_thr_copy_B.partition_D(sB);  // (BCPY,BCPY_N,BCPY_K,PIPE)

    //
    // PREDICATES
    //

    // Allocate predicate tensors for m and n
    Tensor tApA = make_tensor<bool>(make_shape(size<1>(tAsA), size<2>(tAsA)),
                                    Stride<_1, _0>{});
    Tensor tBpB = make_tensor<bool>(make_shape(size<1>(tBsB), size<2>(tBsB)),
                                    Stride<_1, _0>{});

    // Construct identity layout for sA and sB
    Tensor cA = make_identity_tensor(make_shape(
        size<0>(sA), size<1>(sA)));  // (BLK_M,BLK_K) -> (blk_m,blk_k)
    Tensor cB = make_identity_tensor(make_shape(
        size<0>(sB), size<1>(sB)));  // (BLK_N,BLK_K) -> (blk_n,blk_k)

    // Repeat the partitioning with identity layouts
    Tensor tAcA = gmem_thr_copy_A.partition_S(
        cA);  // (ACPY,ACPY_M,ACPY_K) -> (blk_m,blk_k)
    Tensor tBcB = gmem_thr_copy_B.partition_S(
        cB);  // (BCPY,BCPY_N,BCPY_K) -> (blk_n,blk_k)

    // Set predicates for m bounds
    CUTLASS_PRAGMA_UNROLL
    for (int m = 0; m < size<0>(tApA); ++m) {
      tApA(m, 0) = get<0>(tAcA(0, m, 0)) <
                   get<0>(residue_mnk);  // blk_m coord < residue_m
    }
    // Set predicates for n bounds
    CUTLASS_PRAGMA_UNROLL
    for (int n = 0; n < size<0>(tBpB); ++n) {
      tBpB(n, 0) = get<0>(tBcB(0, n, 0)) <
                   get<1>(residue_mnk);  // blk_n coord < residue_n
    }

    // Start async loads for 0th k-tile, where we take care of the k residue
    constexpr int k_pipe = 0;

    if (*k_tile_iter % TILE_NUM_IN_BLOCK == 0 && *k_tile_iter < size<3>(tAgA)) {
      record_cycle();
      if (thread_idx == 0) {
        // Wait for matrix A
        while (true != task_table(blockIdx_x, *k_tile_iter / TILE_NUM_IN_BLOCK)
                           .load(cuda::memory_order_acquire)) {
          __nanosleep(40);

          // Wait for matrix B
          while (true !=
                 task_table(*k_tile_iter / TILE_NUM_IN_BLOCK, blockIdx_y)
                     .load(cuda::memory_order_acquire)) {
            __nanosleep(40);
          }
        }
      }
      __syncthreads();
      record_cycle();
    }

    Tensor tAgAk = tAgA(_, _, _, *k_tile_iter);
    CUTLASS_PRAGMA_UNROLL
    for (int k = 0; k < size<2>(tAsA); ++k) {
      if (get<1>(tAcA(0, 0, k)) >=
          -get<2>(residue_mnk)) {  // blk_k coord < residue_k (gA shifted)
        copy_if(gmem_tiled_copy_A, tApA(_, k), tAgAk(_, _, k),
                tAsA(_, _, k, k_pipe));
      }
    }

    Tensor tBgBk = tBgB(_, _, _, *k_tile_iter);
    CUTLASS_PRAGMA_UNROLL
    for (int k = 0; k < size<2>(tBsB); ++k) {
      if (get<1>(tBcB(0, 0, k)) >=
          -get<2>(residue_mnk)) {  // blk_k coord < residue_k (gB shifted)
        copy_if(gmem_tiled_copy_B, tBpB(_, k), tBgBk(_, _, k),
                tBsB(_, _, k, k_pipe));
      }
    }
    cp_async_fence();
    ++k_tile_iter;
    --k_tile_count;

    // Start async loads for 1st k-tile onwards, no k-residue handling needed
    CUTLASS_PRAGMA_UNROLL
    for (int k_pipe = 1; k_pipe < Stages - 1; ++k_pipe) {
      if (k_tile_count <= 0) {
        clear(tApA);
        clear(tBpB);
      }

      if (*k_tile_iter % TILE_NUM_IN_BLOCK == 0 &&
          *k_tile_iter < size<3>(tAgA)) {
        record_cycle();
        if (thread_idx == 0) {
          // Wait for matrix A
          while (true !=
                 task_table(blockIdx_x, *k_tile_iter / TILE_NUM_IN_BLOCK)
                     .load(cuda::memory_order_acquire)) {
            __nanosleep(40);
          }
          // Wait for matrix B
          while (true !=
                 task_table(*k_tile_iter / TILE_NUM_IN_BLOCK, blockIdx_y)
                     .load(cuda::memory_order_acquire)) {
            __nanosleep(40);
          }
        }
        __syncthreads();
        record_cycle();
      }
      copy_if(gmem_tiled_copy_A, tApA, tAgA(_, _, _, *k_tile_iter),
              tAsA(_, _, _, k_pipe));  // CpAsync

      copy_if(gmem_tiled_copy_B, tBpB, tBgB(_, _, _, *k_tile_iter),
              tBsB(_, _, _, k_pipe));  // CpAsync
      cp_async_fence();
      ++k_tile_iter;
      --k_tile_count;
    }

    //
    // Copy Atom retiling
    //

    auto smem_tiled_copy_A = make_tiled_copy_A(SmemCopyAtomA{}, tiled_mma);
    auto smem_thr_copy_A = smem_tiled_copy_A.get_thread_slice(thread_idx);
    Tensor tCsA = smem_thr_copy_A.partition_S(sA);  // (CPY,CPY_M,CPY_K,PIPE)
    Tensor tCrA_copy_view =
        smem_thr_copy_A.retile_D(tCrA);  // (CPY,CPY_M,CPY_K)
    CUTE_STATIC_ASSERT_V(size<1>(tCsA) == size<1>(tCrA_copy_view));  // CPY_M
    CUTE_STATIC_ASSERT_V(size<2>(tCsA) == size<2>(tCrA_copy_view));  // CPY_K

    auto smem_tiled_copy_B = make_tiled_copy_B(SmemCopyAtomB{}, tiled_mma);
    auto smem_thr_copy_B = smem_tiled_copy_B.get_thread_slice(thread_idx);
    Tensor tCsB = smem_thr_copy_B.partition_S(sB);  // (CPY,CPY_N,CPY_K,PIPE)
    Tensor tCrB_copy_view =
        smem_thr_copy_B.retile_D(tCrB);  // (CPY,CPY_N,CPY_K)
    CUTE_STATIC_ASSERT_V(size<1>(tCsB) == size<1>(tCrB_copy_view));  // CPY_N
    CUTE_STATIC_ASSERT_V(size<2>(tCsB) == size<2>(tCrB_copy_view));  // CPY_K

    //
    // PIPELINED MAIN LOOP
    //

    // Current pipe index in smem to read from
    int smem_pipe_read = 0;
    // Current pipe index in smem to write to
    int smem_pipe_write = Stages - 1;

    Tensor tCsA_p = tCsA(_, _, _, smem_pipe_read);
    Tensor tCsB_p = tCsB(_, _, _, smem_pipe_read);

    // Size of the register pipeline
    const auto K_BLOCK_MAX = size<2>(tCrA);

    // // PREFETCH register pipeline
    if (K_BLOCK_MAX > 1) {
      // Wait until our first prefetched tile is loaded in
      cp_async_wait<Stages - 2>();
      __syncthreads();

      // Prefetch the first rmem from the first k-tile
      copy(smem_tiled_copy_A, tCsA_p(_, _, Int<0>{}),
           tCrA_copy_view(_, _, Int<0>{}));
      copy(smem_tiled_copy_B, tCsB_p(_, _, Int<0>{}),
           tCrB_copy_view(_, _, Int<0>{}));
    }

    CUTLASS_PRAGMA_NO_UNROLL
    for (; k_tile_count > -(Stages - 1); --k_tile_count) {
      // Pipeline the outer products with a static for loop.
      //
      // Note, the for_each() function is required here to ensure `k_block` is
      // of type Int<N>.
      for_each(make_int_sequence<K_BLOCK_MAX>{}, [&](auto k_block) {
        if (k_block == K_BLOCK_MAX - 1) {
          // Slice the smem_pipe_read smem
          tCsA_p = tCsA(_, _, _, smem_pipe_read);
          tCsB_p = tCsB(_, _, _, smem_pipe_read);

          // Commit the smem for smem_pipe_read
          cp_async_wait<Stages - 2>();
          __syncthreads();
        }

        // Load A, B shmem->regs for k_block+1
        auto k_block_next = (k_block + Int<1>{}) % K_BLOCK_MAX;  // static
        copy(smem_tiled_copy_A, tCsA_p(_, _, k_block_next),
             tCrA_copy_view(_, _, k_block_next));
        copy(smem_tiled_copy_B, tCsB_p(_, _, k_block_next),
             tCrB_copy_view(_, _, k_block_next));
        // Copy gmem to smem before computing gemm on each k-pipe
        if (k_block == 0) {
          // Set all predicates to false if we are going to overshoot bounds
          if (k_tile_count <= 0) {
            clear(tApA);
            clear(tBpB);
          }

          if (*k_tile_iter % TILE_NUM_IN_BLOCK == 0 &&
              *k_tile_iter < size<3>(tAgA)) {
            record_cycle();
            if (thread_idx == 0) {
              // Wait for matrix A
              while (true !=
                     task_table(blockIdx_x, *k_tile_iter / TILE_NUM_IN_BLOCK)
                         .load(cuda::memory_order_acquire)) {
                __nanosleep(40);
              }

              // Wait for matrix B
              while (true !=
                     task_table(*k_tile_iter / TILE_NUM_IN_BLOCK, blockIdx_y)
                         .load(cuda::memory_order_acquire)) {
                __nanosleep(40);
              }
            }
            __syncthreads();
            record_cycle();
          }
          copy_if(gmem_tiled_copy_A, tApA, tAgA(_, _, _, *k_tile_iter),
                  tAsA(_, _, _, smem_pipe_write));
          copy_if(gmem_tiled_copy_B, tBpB, tBgB(_, _, _, *k_tile_iter),
                  tBsB(_, _, _, smem_pipe_write));
          cp_async_fence();
          ++k_tile_iter;

          // Advance the pipe
          // -- Doing it here accounts for K_BLOCK_MAX = 1 (no rmem pipe)
          smem_pipe_write = smem_pipe_read;
          ++smem_pipe_read;
          smem_pipe_read = (smem_pipe_read == Stages) ? 0 : smem_pipe_read;
        }

        // Thread-level register gemm for k_block
        cute::gemm(tiled_mma, accum, tCrA(_, _, k_block), tCrB(_, _, k_block),
                   accum);
      });
    }
  }

  ////////////// Epilogue Start //////////////

  Tensor sC = make_tensor(make_smem_ptr(smem.factorize.smem_c.data()),
                          SmemLayoutC{});  // (BLK_M,BLK_N)
  Tensor sDiag = make_tensor(make_smem_ptr(smem.factorize.smem_diag.data()),
                             SmemLayoutC{});  // (BLK_M)

  Tensor tCsC = thr_mma.partition_C(sC);  // (MMA,MMA_M,MMA_N)

  CUTLASS_PRAGMA_UNROLL
  for (int i = 0; i < size(accum); ++i) {
    tCsC(i) = -accum(i);
  }

  if (blockIdx_x != blockIdx_y) {
    record_cycle();
    const auto blockIdx_diag = min(blockIdx_x, blockIdx_y);
    if (thread_idx == 0) {
      while (true != task_table(blockIdx_diag, blockIdx_diag)
                         .load(cuda::memory_order_acquire)) {
        __nanosleep(40);
      }
    }
    __syncthreads();
    record_cycle();

    // Get the appropriate blocks for this thread block
    const Tensor gDiag =
        local_tile(mC, TileShape{}, make_coord(blockIdx_diag, blockIdx_diag, _),
                   Step<_1, _1, X>{});  // (BLK_M,BLK_N)

    // Partition the copying of C tiles across the threads
    GmemTiledCopyC gmem_tiled_copy_C;
    auto gmem_thr_copy_C = gmem_tiled_copy_C.get_slice(thread_idx);

    Tensor tDgD = gmem_thr_copy_C.partition_S(gDiag);  // (ACPY,ACPY_M,ACPY_N)
    Tensor tDsD = gmem_thr_copy_C.partition_D(sDiag);  // (ACPY,ACPY_M,ACPY_N)

    copy(gmem_tiled_copy_C, tDgD, tDsD);
    cp_async_fence();
  }

  cp_async_wait<0>();
  __syncthreads();

  record_cycle();

  if (blockIdx_x < blockIdx_y) {
    // TRSM Upper Lx=A
    lx_solve_64x64<size(mma)>(thread_idx, LEGAL_BLK_N, sDiag, sC, gC);
  } else if (blockIdx_x > blockIdx_y) {
    // TRSM Lower xU=A
    xu_solve_64x64<size(mma)>(thread_idx, LEGAL_BLK_M, sDiag, sC, gC);
  } else {
    // GETRF diagonal LU=A
    // lu_64x64<size(mma), enable_static_pivoting>(
    //     thread_idx, LEGAL_BLK_M, LEGAL_BLK_N, sC, gC, pivot_count_ptr);
    lu_64x64_naive<size(mma), enable_static_pivoting>(
        thread_idx, LEGAL_BLK_M, LEGAL_BLK_N, sC, gC, pivot_count_ptr,
        criterion);
    copy_if(tCpC, tCsC, tCgC);
  }

  record_cycle();

  __syncthreads();
  if (thread_idx == 0) {
    task_table(blockIdx_x, blockIdx_y).store(true, cuda::memory_order_release);
  }
#endif
}

template <bool enable_static_pivoting, class ShapeType, class T, int threads>
struct GetrfStaticPivot {
 private:
  constexpr static int Stages = 4;

  // Define CTA tile sizes (static)
  using bM = cute::_64;
  using bN = cute::_64;
  using bK = cute::_16;
  using TileShape = cute::Shape<bM, bN, bK>;  // (BLK_M, BLK_N, BLK_K)

  using SmemLayoutC = decltype(cute::composition(
      cute::Swizzle<6, 0, 6>{},
      cute::Layout<cute::Shape<bM, bN>>{}));  // (m,n) -> smem_idx

  CUTE_STATIC_ASSERT(threads == 128 || threads == 256);

  // // A  (M,K)  M-Major
  using SmemLayoutAtomA = decltype(cute::composition(
      cute::Swizzle<2, 2, 2>{},
      cute::Layout<cute::Shape<cute::_16, cute::_4>>{}));  // M, K
  using SmemCopyAtomA = cute::Copy_Atom<cute::DefaultCopy, double>;
  using GmemTiledCopyA = decltype(cute::make_tiled_copy(
      cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEALWAYS<double>,
                      double>{},  // CopyAtom
      cute::Layout<cute::Shape<cute::_16, cute::Int<threads / 16>>>{},
      cute::Layout<cute::Shape<cute::_1, cute::_1>>{}));

  // // B  (N,K)  K-Major
  using SmemLayoutAtomB = decltype(cute::composition(
      cute::Swizzle<2, 0, 4>{},
      cute::Layout<cute::Shape<cute::_4, cute::_16>>{}));  // N, K
  using SmemCopyAtomB = cute::Copy_Atom<cute::DefaultCopy, double>;
  using GmemTiledCopyB = decltype(cute::make_tiled_copy(
      cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEALWAYS<double>,
                      double>{},  // CopyAtom
      cute::Layout<cute::Shape<cute::Int<threads / 16>, cute::_16>,
                   cute::Stride<cute::_16, cute::_1>>{},
      cute::Layout<cute::Shape<cute::_1, cute::_1>>{}));

  using GmemTiledCopyC = decltype(cute::make_tiled_copy(
      cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEALWAYS<double>,
                      double>{},  // CopyAtom
      cute::Layout<cute::Shape<cute::_16, cute::Int<threads / 16>>>{},
      cute::Layout<cute::Shape<cute::_1, cute::_1>>{}));

  using TiledMma =
      cute::TiledMMA<cute::MMA_Atom<cute::SM80_8x8x4_F64F64F64F64_TN>,
                     cute::Layout<cute::Shape<
                         cute::_2, cute::Int<threads / 32 / 2>, cute::_1>>,
                     cute::Tile<cute::Layout<cute::Shape<cute::_2, cute::_16>>,
                                cute::Layout<cute::Shape<cute::_2, cute::_16>>,
                                cute::Underscore>>;

  using SmemLayoutA = decltype(cute::tile_to_shape(
      SmemLayoutAtomA{},
      cute::make_shape(cute::shape<0>(TileShape{}), cute::shape<2>(TileShape{}),
                       cute::Int<Stages>{})));
  using SmemLayoutB = decltype(cute::tile_to_shape(
      SmemLayoutAtomB{},
      cute::make_shape(cute::shape<1>(TileShape{}), cute::shape<2>(TileShape{}),
                       cute::Int<Stages>{})));

 public:
  union Smem {
    struct {
      cute::array_aligned<T, cute::cosize_v<SmemLayoutA>> smem_a;
      cute::array_aligned<T, cute::cosize_v<SmemLayoutB>> smem_b;
    } update;

    struct {
      cute::array_aligned<T, cute::cosize_v<SmemLayoutC>> smem_c;
      cute::array_aligned<T, cute::cosize_v<SmemLayoutC>> smem_diag;
    } factorize;
  };

  static cdlsStatus_t get_buffer_size(const int m, const int n,
                                      size_t* buffer_size) {
    if (m <= 0) {
      return CDLS_STATUS_INVALID_VALUE;
    }
    if (m != n) {
      return CDLS_STATUS_INVALID_VALUE;
    }
    *buffer_size = sizeof(cuda::atomic<int>) + sizeof(cuda::atomic<bool>) *
                                                   ceil_div(m, bM{}) *
                                                   ceil_div(n, bN{});
    return CDLS_STATUS_SUCCESS;
  }

  static cdlsStatus_t call(const ShapeType m, const ShapeType n, T* C,
                           const ShapeType ldc, void* const workspace,
                           int* const pivot_count, const T criterion,
                           int64_t* cycles, const cudaStream_t stream) {
    using namespace cute;

    if (m != n) {
      return CDLS_STATUS_INVALID_VALUE;
    }
    if (ldc < m) {
      return CDLS_STATUS_INVALID_VALUE;
    }
    if (C == nullptr || workspace == nullptr) {
      return CDLS_STATUS_INVALID_VALUE;
    }
    size_t buffer_size;
    get_buffer_size(m, m, &buffer_size);
    const auto workspace_ptr = static_cast<std::byte*>(workspace);
    cudaMemsetAsync(workspace, 0, buffer_size, stream);
    const auto task_index_ptr =
        reinterpret_cast<cuda::atomic<int>*>(workspace_ptr);
    const auto task_table = reinterpret_cast<cuda::atomic<bool>*>(
        workspace_ptr + sizeof(cuda::atomic<int>));

    const auto pivot_count_ptr =
        reinterpret_cast<cuda::atomic<int>*>(pivot_count);
    static_assert(sizeof(int) == sizeof(cuda::atomic<int>));

    dim3 dimBlock(size(TiledMma{}));
    dim3 dimGrid(size(ceil_div(m, bM{})), size(ceil_div(m, bN{})));

    const auto smem_byte = sizeof(Smem);

    if (smem_byte >= (48 << 10)) {
      {
        cudaFuncSetAttribute(
            getrf_static_pivot_kernel<
                enable_static_pivoting, ShapeType, T, Stages, TileShape,
                GmemTiledCopyA, SmemCopyAtomA, SmemLayoutA, GmemTiledCopyB,
                SmemCopyAtomB, SmemLayoutB, SmemLayoutC, GmemTiledCopyC, Smem,
                TiledMma, size(TiledMma{})>,
            cudaFuncAttributeMaxDynamicSharedMemorySize, smem_byte);
      }
    }

    getrf_static_pivot_kernel<
        enable_static_pivoting, ShapeType, T, Stages, TileShape, GmemTiledCopyA,
        SmemCopyAtomA, SmemLayoutA, GmemTiledCopyB, SmemCopyAtomB, SmemLayoutB,
        SmemLayoutC, GmemTiledCopyC, Smem, TiledMma, size(TiledMma{})>
        <<<dimGrid, dimBlock, smem_byte, stream>>>(m, C, ldc, task_index_ptr,
                                                   task_table, pivot_count_ptr,
                                                   criterion, cycles);
    return CDLS_STATUS_SUCCESS;
  }
};
}  // namespace

extern "C" cdlsStatus_t cdlsDgetrf_record_cta_cycles_bufferSize(
    const long m, const long n, size_t* buffer_size) {
  if (m != n) {
    return CDLS_STATUS_INVALID_VALUE;
  }
  return GetrfStaticPivot<false, long, double, 256>::get_buffer_size(
      m, m, buffer_size);
}

extern "C" cdlsStatus_t cdlsDgetrf_record_cta_cycles(const cdlsHandle_t handle,
                                                     const long m, const long n,
                                                     double* C, const long ldc,
                                                     void* const workspace,
                                                     int* const pivot_count,
                                                     int64_t* cycles) {
  if (m != n) {
    return CDLS_STATUS_INVALID_VALUE;
  }
  if (m <= 10240 && n < 10240 && ldc <= 10240) {
    return GetrfStaticPivot<false, int, double, 256>::call(
        static_cast<int>(m), static_cast<int>(n), C, static_cast<int>(ldc),
        workspace, pivot_count, 0, cycles,
        static_cast<cudaStream_t>(handle->stream_work));
  } else {
    return GetrfStaticPivot<false, long, double, 256>::call(
        m, m, C, ldc, workspace, pivot_count, 0, cycles,
        static_cast<cudaStream_t>(handle->stream_work));
  }
}

using TC = double;

static void compute_LU_product(const thrust::host_vector<TC>& LU_factor,
                               thrust::host_vector<TC>& LU_product, const int m,
                               const int n) {
  LU_product.resize(m * n);

  for (int i = 0; i < m; ++i) {
    for (int j = 0; j < n; ++j) {
      TC sum = 0.0;
      for (int k = 0; k < std::min(m, n); ++k) {
        TC L_ik;
        if (i == k) {
          L_ik = 1.0;
        } else if (i > k) {
          L_ik = LU_factor[i + k * m];
        } else {
          L_ik = 0.0;
        }

        TC U_kj = (k <= j) ? LU_factor[k + j * m] : 0.0;

        sum += L_ik * U_kj;
      }
      LU_product[i + j * m] = sum;
    }
  }
}

static void device_init(int device_id) {
  cudaDeviceProp device_prop;
  std::size_t device_free_physmem;
  std::size_t device_total_physmem;

  CDLS_CHECK_CUDA_ERROR(cudaSetDevice(device_id));
  CDLS_CHECK_CUDA_ERROR(
      cudaMemGetInfo(&device_free_physmem, &device_total_physmem));
  CDLS_CHECK_CUDA_ERROR(cudaGetDeviceProperties(&device_prop, device_id));

  if (device_prop.major < 1) {
    fprintf(stderr, "Device does not support CUDA.\n");
    exit(1);
  }

  printf("Using device %d: %s  (SM%d, %d SMs)\n", device_id, device_prop.name,
         device_prop.major * 10 + device_prop.minor,
         device_prop.multiProcessorCount);
  fflush(stdout);
}

static void process_and_store_cycles(
    const int block_num, const std::string& cycle_path,
    const std::string& ns_path, const thrust::device_vector<int64_t>& cycles) {
  using namespace cute;
  const thrust::host_vector<int64_t> cycles_host = cycles;
  thrust::host_vector<int64_t> cycles_host_permuted;
  cycles_host_permuted.resize(cycles.size());

  const auto layout =
      make_layout(make_shape(block_num * block_num, 2 * (block_num - 1) + 4),
                  LayoutRight{});

  const auto layout_permuted = make_layout(
      make_shape(block_num, block_num, 2 * (block_num - 1) + 4), LayoutRight{});

  const auto tensor = make_tensor(cycles_host.data(), layout);
  auto tensor_permuted =
      make_tensor(cycles_host_permuted.data(), layout_permuted);

  for (int task_idx = 0; task_idx < block_num * block_num; ++task_idx) {
    const auto [blockIdx_x, blockIdx_y] = index_to_coord(task_idx, block_num);
    copy(tensor(task_idx, _), tensor_permuted(blockIdx_x, blockIdx_y, _));

    const auto start_cycle = tensor_permuted(blockIdx_x, blockIdx_y, 0);
    for (int i = 0; i < size(tensor_permuted(blockIdx_x, blockIdx_y, _)); ++i) {
      tensor_permuted(blockIdx_x, blockIdx_y, i) -= start_cycle;
    }

    for (int i = 0; i < size(tensor_permuted(blockIdx_x, blockIdx_y, _)); ++i) {
      const auto diag = min(blockIdx_x, blockIdx_y);
      if (blockIdx_x == blockIdx_y) {
        if (i >= (1 /* start */ + 2 * diag /* gemm */ + 1 /* getrf starts */ +
                  1 /* getrf ends */)) {
          tensor_permuted(blockIdx_x, blockIdx_y, i) = 0;
        }
      } else {
        if (i >=
            (1 /* start */ + 2 * diag /* gemm */ + 1 /* wait for diag */ +
             1 /* diag done */ + 1 /* trsm starts */ + 1 /* trsm ends */)) {
          tensor_permuted(blockIdx_x, blockIdx_y, i) = 0;
        }
      }
    }
  }

  int device;
  CDLS_CHECK_CUDA_ERROR(cudaGetDevice(&device));
  cudaDeviceProp prop;
  CDLS_CHECK_CUDA_ERROR(cudaGetDeviceProperties(&prop, device));
  const double clockRate_kHz = prop.clockRate;

  std::ostringstream oss_clock;
  std::ostringstream oss_ns;

  const int cols = 2 * (block_num - 1) + 4;

  for (int block_row = 0; block_row < block_num; ++block_row) {
    for (int block_col = 0; block_col < block_num; ++block_col) {
      for (int element_col = 0; element_col < cols; ++element_col) {
        int64_t current_cycles =
            tensor_permuted(block_row, block_col, element_col);
        const double time_ns =
            static_cast<double>(current_cycles) * 1000.0 / clockRate_kHz;

        oss_clock << current_cycles;
        if (element_col < cols - 1) {
          oss_clock << ",";
        }

        oss_ns << time_ns;
        if (element_col < cols - 1) {
          oss_ns << ",";
        }
      }
      oss_clock << "\n";
      oss_ns << "\n";
    }
  }

  std::ofstream outfile_clock(cycle_path);
  if (outfile_clock.is_open()) {
    outfile_clock << oss_clock.str();
    outfile_clock.close();
  }

  std::ofstream outfile_ns(ns_path);
  if (outfile_ns.is_open()) {
    outfile_ns << oss_ns.str();
    outfile_ns.close();
  }
}

int main(int argc, char** argv) {
  cxxopts::Options options("Fine-Grained CTA-Level GETRF Profiler");

  options.add_options()("m", "The matrix size",
                        cxxopts::value<long>()->default_value("512"));
  options.add_options()("d,device", "The device ID",
                        cxxopts::value<int>()->default_value("0"));
  options.add_options()("r,repeat", "Number of repetitions",
                        cxxopts::value<int>()->default_value("10"));
  options.add_options()("n,ns_path", "Path to store nano seconds csv file",
                        cxxopts::value<std::string>());
  options.add_options()("c,cycle_path", "Path to store cycles csv file",
                        cxxopts::value<std::string>());
  options.add_options()("h,help", "Print usage");

  const auto result = options.parse(argc, argv);

  if (result.count("help")) {
    std::cout << options.help() << std::endl;
    return 0;
  }

  const long m = result["m"].as<long>();
  const int device = result["device"].as<int>();
  const int repeat = result["repeat"].as<int>();

  const std::string cycle_path = result["cycle_path"].as<std::string>();
  const std::string ns_path = result["ns_path"].as<std::string>();

  printf("Parameters: m = %ld | device = %d | repeat = %d\n", m, device,
         repeat);

  const long n = m;

  device_init(device);

  thrust::host_vector<TC> h_C(m * n);

  if (m <= 1024) {
    std::random_device rd;
    std::mt19937 gen(rd());

    std::uniform_real_distribution<float> dis(0.0, 1.0);

    for (int col = 0; col < n; ++col) {
      for (int row = 0; row < m; ++row) {
        if (row != col) {
          h_C[row + col * m] = dis(gen);
        } else {
          h_C[row + col * m] = m;
        }
      }
    }
  } else {
    for (int col = 0; col < n; ++col) {
      for (int row = 0; row < m; ++row) {
        if (row != col) {
          h_C[row + col * m] = 0;
        } else {
          h_C[row + col * m] = m;
        }
      }
    }
  }

  thrust::device_vector<TC> d_C = h_C;
  thrust::device_vector<TC> d_C_backup = d_C;

  cdlsHandle_t cdls_handle;

  CDLS_CHECK_CDLS_ERROR(cdlsCreate(&cdls_handle));

  int* d_info = nullptr;
  CDLS_CHECK_CUDA_ERROR(
      cudaMalloc(reinterpret_cast<void**>(&d_info), sizeof(int)));

  const int block_num = cute::ceil_div(m, 64);

  thrust::device_vector<int64_t> cycles;
  cycles.resize(block_num * block_num * (2 * (block_num - 1) + 4));

  const long ldC = m;

  size_t workspace_size;
  cdlsDgetrf_record_cta_cycles_bufferSize(m, m, &workspace_size);
  thrust::device_vector<std::byte> workspace{workspace_size};
  // Warmup
  cdlsDgetrf_record_cta_cycles(cdls_handle, m, m, d_C.data().get(), ldC,
                               workspace.data().get(), d_info,
                               cycles.data().get());
  CDLS_CHECK_CUDA_ERROR(cudaDeviceSynchronize());

  double total_time = 0.0;

  for (int i = 0; i < repeat; ++i) {
    d_C = d_C_backup;
    CDLS_CHECK_CUDA_ERROR(cudaDeviceSynchronize());

    const auto start = std::chrono::high_resolution_clock::now();
    cdlsDgetrf_record_cta_cycles(cdls_handle, m, m, d_C.data().get(), ldC,
                                 workspace.data().get(), d_info,
                                 cycles.data().get());
    CDLS_CHECK_CUDA_ERROR(cudaDeviceSynchronize());
    const auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> elapsed = end - start;
    total_time += elapsed.count();
  }

  if (repeat != 0) {
    const double avg_time = total_time / repeat;
    const double flops = static_cast<double>(m) * (m - 1) * (4 * m + 1) / 6.0;
    const double gflops = flops / (avg_time * 1e9);

    printf("Ours Average Time: %f s\n", avg_time);
    printf("Ours Performance: %f GFLOP/s\n", gflops);
  }

  CDLS_CHECK_CUDA_ERROR(cudaPeekAtLastError());
  CDLS_CHECK_CUDA_ERROR(cudaDeviceSynchronize());

  CDLS_CHECK_CDLS_ERROR(cdlsDestroy(cdls_handle));

  if (m <= 1024) {
    thrust::host_vector<TC> LU_factor = d_C;

    thrust::host_vector<TC> LU_product;

    compute_LU_product(LU_factor, LU_product, m, n);

    double max_error = -1;
    for (int j = 0; j < m * n; ++j) {
      max_error = std::max<double>(max_error, std::abs(LU_product[j] - h_C[j]));
    }
    printf("Ours max_error = %e\n", max_error);
  }

  process_and_store_cycles(block_num, cycle_path, ns_path, cycles);

  CDLS_CHECK_CUDA_ERROR(cudaFree(d_info));

  return 0;
}
