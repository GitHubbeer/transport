#pragma once
#include "../../common/getrf/numeric.h"

namespace cdls::cuda_detail::getrf {
using cdls::detail::getrf::reciprocal_safe;
}  // namespace cdls::cuda_detail::getrf
