#pragma once

#include "config.cuh"
#include "diagonal.cuh"
#include "schedule.cuh"
#include "triangular.cuh"

namespace cdls::cuda_detail::getrf {

template <bool StaticPivot, bool vectorized, int MinBlocks>
struct TiledGetrf {
  static constexpr bool enable_static_pivoting = StaticPivot;
  static constexpr int min_blocks = MinBlocks;
  using T = double;
  using ShapeType = MatrixIndex;
  static constexpr int threads = kTileThreads;
  // SM80 no-pivot measurements favor three copy stages: shorter lookahead
  // helps dependency-bound tiles without the large-size loss of two stages.
  constexpr static int Stages =
      enable_static_pivoting ? kStaticPivotStages : kNoPivotStages;

  // Define CTA tile sizes (static)
  using bM = cute::Int<kTileExtent>;
  using bN = cute::Int<kTileExtent>;
  using bK = cute::Int<kCopyK>;
  using TileShape = cute::Shape<bM, bN, bK>;  // (BLK_M, BLK_N, BLK_K)

  using SmemLayoutC = cute::Layout<
      cute::Shape<bM, bN>,
      cute::Stride<cute::_1, cute::Int<kTileExtent + kSharedPadding>>>;

  CUTE_STATIC_ASSERT(threads == kTileThreads);

  // A  (M,K)  M-Major
  using SmemLayoutAtomA = decltype(cute::composition(
      cute::Swizzle<2, 2, 2>{},
      cute::Layout<cute::Shape<cute::_16, cute::_4>>{}));  // M, K
  using SmemCopyAtomA = cute::Copy_Atom<cute::DefaultCopy, double>;
  // Two adjacent doubles per instruction require even extents and alignment.
  using CopyType = std::conditional_t<vectorized, cute::uint128_t, double>;
  using GmemTiledCopyA = decltype(cute::make_tiled_copy(
      cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEALWAYS<CopyType>, double>{},
      cute::Layout<cute::Shape<cute::Int<kCopyRowLanes>,
                               cute::Int<threads / kCopyRowLanes>>>{},
      cute::Layout<cute::Shape<cute::Int<vectorized ? 2 : 1>, cute::_1>>{}));

  // B  (N,K)  K-Major
  using ScalarSmemLayoutAtomB = decltype(cute::composition(
      cute::Swizzle<2, 0, 4>{},
      cute::Layout<cute::Shape<cute::_4, cute::_16>>{}));
  // K-contiguous shared storage preserves the 16-byte copy in both memories.
  using VectorSmemLayoutAtomB = decltype(cute::composition(
      cute::Swizzle<2, 2, 2>{},
      cute::Layout<cute::Shape<cute::_4, cute::_16>,
                   cute::Stride<cute::_16, cute::_1>>{}));
  using SmemLayoutAtomB = std::conditional_t<vectorized, VectorSmemLayoutAtomB,
                                             ScalarSmemLayoutAtomB>;
  using SmemCopyAtomB = cute::Copy_Atom<cute::DefaultCopy, double>;
  using CopyThreadsK = cute::Int<vectorized ? 8 : 16>;
  using GmemTiledCopyB = decltype(cute::make_tiled_copy(
      cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEALWAYS<CopyType>, double>{},
      cute::Layout<
          cute::Shape<cute::Int<threads / CopyThreadsK::value>, CopyThreadsK>,
          cute::Stride<CopyThreadsK, cute::_1>>{},
      cute::Layout<cute::Shape<cute::_1, cute::Int<vectorized ? 2 : 1>>>{}));

  using GmemTiledCopyC = decltype(cute::make_tiled_copy(
      cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEALWAYS<double>,
                      double>{},  // CopyAtom
      cute::Layout<cute::Shape<cute::Int<kCopyRowLanes>,
                               cute::Int<threads / kCopyRowLanes>>>{},
      cute::Layout<cute::Shape<cute::_1, cute::_1>>{}));

  using TiledMma = cute::TiledMMA<
      cute::MMA_Atom<cute::SM80_8x8x4_F64F64F64F64_TN>,
      cute::Layout<
          cute::Shape<cute::_2, cute::Int<threads / kWarpSize / 2>, cute::_1>>,
      cute::Tile<cute::Layout<cute::Shape<cute::_2, cute::_16>>,
                 cute::Layout<cute::Shape<cute::_2, cute::_16>>,
                 cute::Underscore>>;

  using SmemLayoutA = decltype(cute::tile_to_shape(
      SmemLayoutAtomA{},
      cute::make_shape(cute::shape<0>(TileShape{}), cute::shape<2>(TileShape{}),
                       cute::Int<Stages>{})));
  using SmemLayoutB = decltype(cute::tile_to_shape(
      SmemLayoutAtomB{},
      cute::make_shape(cute::shape<1>(TileShape{}), cute::shape<2>(TileShape{}),
                       cute::Int<Stages>{})));

  union Smem {
    struct {
      cute::array_aligned<T, cute::cosize_v<SmemLayoutA>> smem_a;
      cute::array_aligned<T, cute::cosize_v<SmemLayoutB>> smem_b;
    } update;

    struct {
      cute::array_aligned<T, cute::cosize_v<SmemLayoutC>> smem_c;
      cute::array_aligned<T, cute::cosize_v<SmemLayoutC>> smem_diag;
    } factorize;
  };

  static cdlsStatus_t call(const ShapeType m, T* C, const ShapeType ldc,
                           void* const workspace, int* const pivot_count,
                           const T criterion, const cudaStream_t stream,
                           const int panels);
};

template <class Config>
// Use a measured register/occupancy tradeoff for dependency-bound sizes.
__global__ void __launch_bounds__(Config::threads, Config::min_blocks)
    getrf_tiled_kernel(const MatrixIndex shape_M, double* const A,
                       const MatrixIndex ldA,
                       TaskAtomic<int>* const task_index_ptr,
                       TaskAtomic<bool>* const task_table_ptr,
                       cuda::atomic<int>* const pivot_count_ptr,
                       const double criterion) {
  using T = double;
  using ShapeType = MatrixIndex;
  using TileShape = typename Config::TileShape;
  using GmemTiledCopyA = typename Config::GmemTiledCopyA;
  using SmemCopyAtomA = typename Config::SmemCopyAtomA;
  using SmemLayoutA = typename Config::SmemLayoutA;
  using GmemTiledCopyB = typename Config::GmemTiledCopyB;
  using SmemCopyAtomB = typename Config::SmemCopyAtomB;
  using SmemLayoutB = typename Config::SmemLayoutB;
  using SmemLayoutC = typename Config::SmemLayoutC;
  using GmemTiledCopyC = typename Config::GmemTiledCopyC;
  using Smem = typename Config::Smem;
  using TiledMma = typename Config::TiledMma;
  constexpr auto Stages = Config::Stages;
  constexpr auto threads = Config::threads;
  constexpr auto enable_static_pivoting = Config::enable_static_pivoting;
  using namespace cute;

  int thread_idx = static_cast<int>(threadIdx.x);

  const auto task_index = [&] {
    // Separate from the tile union: another warp may already start tile writes.
    __shared__ int task_index[1];
    if (thread_idx == 0) {
      *task_index = task_index_ptr->fetch_add(1, cuda::memory_order_relaxed);
    }
    __syncthreads();
    return *task_index;
  }();

  constexpr static auto BLK_M = size<0>(TileShape{});
  constexpr static auto BLK_N = size<1>(TileShape{});
  constexpr static auto BLK_K = size<2>(TileShape{});
  static_assert(BLK_M == BLK_N);

  constexpr static auto TILE_NUM_IN_BLOCK = BLK_M / BLK_K;
  static_assert(BLK_M % BLK_K == 0);
  static_assert(BLK_M >= BLK_K);

  const int BLOCK_NUM = ceil_div(shape_M, BLK_M);

  const auto blockIdx_ = index_to_coord(task_index, BLOCK_NUM);
  const auto blockIdx_x = blockIdx_.row;
  const auto blockIdx_y = blockIdx_.col;

  Tensor task_table = make_tensor(make_gmem_ptr(task_table_ptr),
                                  make_shape(BLOCK_NUM, BLOCK_NUM));

  const auto dA = make_stride(_1{}, ldA);  // (dM, dK)
  const auto dB = make_stride(ldA, _1{});  // (dN, dK)
  const auto dC = make_stride(_1{}, ldA);  // (dM, dN)

  const auto shape_MNK =
      make_shape(shape_M, shape_M, BLK_M * min(blockIdx_x, blockIdx_y));

  // Preconditions
  CUTE_STATIC_ASSERT_V(rank(shape_MNK) == Int<3>{});    // (M, N, K)
  CUTE_STATIC_ASSERT_V(rank(TileShape{}) == Int<3>{});  // (BLK_M, BLK_N, BLK_K)

  TiledMma mma{};
  CUTE_STATIC_ASSERT(size(mma) == threads);

  static_assert(is_static<SmemLayoutA>::value);
  static_assert(is_static<SmemLayoutB>::value);
  static_assert(is_static<SmemLayoutC>::value);

  CUTE_STATIC_ASSERT_V(size<0>(SmemLayoutA{}) ==
                       size<0>(TileShape{}));  // BLK_M
  CUTE_STATIC_ASSERT_V(size<0>(SmemLayoutC{}) ==
                       size<0>(TileShape{}));  // BLK_M
  CUTE_STATIC_ASSERT_V(size<0>(SmemLayoutB{}) ==
                       size<1>(TileShape{}));  // BLK_N
  CUTE_STATIC_ASSERT_V(size<1>(SmemLayoutC{}) ==
                       size<1>(TileShape{}));  // BLK_N
  CUTE_STATIC_ASSERT_V(size<1>(SmemLayoutA{}) ==
                       size<2>(TileShape{}));  // BLK_K
  CUTE_STATIC_ASSERT_V(size<1>(SmemLayoutB{}) ==
                       size<2>(TileShape{}));  // BLK_K

  CUTE_STATIC_ASSERT_V(
      congruent(select<0, 2>(shape_MNK), dA));  // dA strides for shape MK
  CUTE_STATIC_ASSERT_V(
      congruent(select<1, 2>(shape_MNK), dB));  // dB strides for shape NK
  CUTE_STATIC_ASSERT_V(
      congruent(select<0, 1>(shape_MNK), dC));  // dC strides for shape MN

  //
  // Full and Tiled Tensors
  //

  // Represent the full tensors
  Tensor mA =
      make_tensor(make_gmem_ptr(A), select<0, 2>(shape_MNK), dA);  // (M,K)
  Tensor mB =
      make_tensor(make_gmem_ptr(A), select<1, 2>(shape_MNK), dB);  // (N,K)
  Tensor mC =
      make_tensor(make_gmem_ptr(A), select<0, 1>(shape_MNK), dC);  // (M,N)

  // Get the appropriate blocks for this thread block
  auto cta_coord = make_coord(blockIdx_x, blockIdx_y, _);  // (m,n,k)
  Tensor gA = local_tile(mA, TileShape{}, cta_coord,
                         Step<_1, X, _1>{});  // (BLK_M,BLK_K,k)
  Tensor gB = local_tile(mB, TileShape{}, cta_coord,
                         Step<X, _1, _1>{});  // (BLK_N,BLK_K,k)
  Tensor gC = local_tile(mC, TileShape{}, cta_coord,
                         Step<_1, _1, X>{});  // (BLK_M,BLK_N)

  // Allocate the tiled_mma and the accumulators for the (M,N) blk_shape
  TiledMma tiled_mma;
  Tensor accum = partition_fragment_C(
      tiled_mma, take<0, 2>(TileShape{}));  // (MMA,MMA_M,MMA_N)

  auto k_tile_iter = cute::make_coord_iterator(shape<2>(gA));
  int k_tile_count = size<2>(gA);

  extern __shared__ char shared_memory[];
  Smem& smem = *reinterpret_cast<Smem*>(shared_memory);

  Tensor sA = make_tensor(make_smem_ptr(smem.update.smem_a.data()),
                          SmemLayoutA{});  // (BLK_M,BLK_K,PIPE)
  Tensor sB = make_tensor(make_smem_ptr(smem.update.smem_b.data()),
                          SmemLayoutB{});  // (BLK_N,BLK_K,PIPE)

  CUTE_STATIC_ASSERT_V(size<0>(gA) == size<0>(sA));    // BLK_M
  CUTE_STATIC_ASSERT_V(size<1>(gA) == size<1>(sA));    // BLK_K
  CUTE_STATIC_ASSERT_V(size<0>(gB) == size<0>(sB));    // BLK_N
  CUTE_STATIC_ASSERT_V(size<1>(gB) == size<1>(sB));    // BLK_K
  CUTE_STATIC_ASSERT_V(size<1>(sA) == size<1>(sB));    // BLK_K
  CUTE_STATIC_ASSERT_V(Int<Stages>{} == size<2>(sA));  // PIPE
  CUTE_STATIC_ASSERT_V(Int<Stages>{} == size<2>(sB));  // PIPE

  // Compute tile residues for predication
  const int LEGAL_BLK_M = min(BLK_M, shape_M - BLK_M * blockIdx_x);
  const int LEGAL_BLK_N = min(BLK_N, shape_M - BLK_M * blockIdx_y);

  //
  // MMA Atom partitioning
  //

  // Tile MMA compute thread partitions and allocate accumulators
  auto thr_mma = tiled_mma.get_thread_slice(thread_idx);
  Tensor tCrA = thr_mma.partition_fragment_A(sA(_, _, 0));  // (MMA,MMA_M,MMA_K)
  Tensor tCrB = thr_mma.partition_fragment_B(sB(_, _, 0));  // (MMA,MMA_N,MMA_K)

  CUTE_STATIC_ASSERT_V(size<1>(tCrA) == size<1>(accum));  // MMA_M
  CUTE_STATIC_ASSERT_V(size<1>(tCrB) == size<2>(accum));  // MMA_N
  CUTE_STATIC_ASSERT_V(size<2>(tCrA) == size<2>(tCrB));   // MMA_K

  const Tensor cC =
      make_identity_tensor(shape(gC));  // (BLK_M,BLK_N) -> (blk_m, blk_n)
  const Tensor tSR_cC = thr_mma.partition_C(
      cC);  // ((Atom, AtomNum), ATOM_M, ATOM_N, TILE_M, TILE_N)

  auto tCpC = [&](auto const&... coords) {
    return elem_less(tSR_cC(coords...), make_shape(LEGAL_BLK_M, LEGAL_BLK_N));
  };

  Tensor tCgC = thr_mma.partition_C(gC);  // (MMA,MMA_M,MMA_N)

  CUTLASS_PRAGMA_UNROLL
  for (int i = 0; i < size(accum); ++i) {
    accum(i) = tCpC(i) ? -tCgC(i) : T(0);
  }

  if (blockIdx_x != 0 && blockIdx_y != 0) {
    // Every update consumes complete diagonal-prefix tiles, including when
    // the output tile has a partial M or N edge. There is no K residue.
    static_assert(Stages - 1 <= TILE_NUM_IN_BLOCK,
                  "Initial prefetch must fit in the first producer tile");

    // Partition the copying of A and B tiles across the threads
    GmemTiledCopyA gmem_tiled_copy_A;
    GmemTiledCopyB gmem_tiled_copy_B;
    auto gmem_thr_copy_A = gmem_tiled_copy_A.get_slice(thread_idx);
    auto gmem_thr_copy_B = gmem_tiled_copy_B.get_slice(thread_idx);

    Tensor tAgA = gmem_thr_copy_A.partition_S(gA);  // (ACPY,ACPY_M,ACPY_K,k)
    Tensor tAsA = gmem_thr_copy_A.partition_D(sA);  // (ACPY,ACPY_M,ACPY_K,PIPE)
    Tensor tBgB = gmem_thr_copy_B.partition_S(gB);  // (BCPY,BCPY_N,BCPY_K,k)
    Tensor tBsB = gmem_thr_copy_B.partition_D(sB);  // (BCPY,BCPY_N,BCPY_K,PIPE)

    //
    // PREDICATES
    //

    // Allocate predicate tensors for m and n
    Tensor tApA = make_tensor<bool>(make_shape(size<1>(tAsA), size<2>(tAsA)),
                                    Stride<_1, _0>{});
    Tensor tBpB = make_tensor<bool>(make_shape(size<1>(tBsB), size<2>(tBsB)),
                                    Stride<_1, _0>{});

    // Construct identity layout for sA and sB
    Tensor cA = make_identity_tensor(make_shape(
        size<0>(sA), size<1>(sA)));  // (BLK_M,BLK_K) -> (blk_m,blk_k)
    Tensor cB = make_identity_tensor(make_shape(
        size<0>(sB), size<1>(sB)));  // (BLK_N,BLK_K) -> (blk_n,blk_k)

    // Repeat the partitioning with identity layouts
    Tensor tAcA = gmem_thr_copy_A.partition_S(
        cA);  // (ACPY,ACPY_M,ACPY_K) -> (blk_m,blk_k)
    Tensor tBcB = gmem_thr_copy_B.partition_S(
        cB);  // (BCPY,BCPY_N,BCPY_K) -> (blk_n,blk_k)

    // Set predicates for m bounds
    CUTLASS_PRAGMA_UNROLL
    for (int m = 0; m < size<0>(tApA); ++m) {
      tApA(m, 0) =
          get<0>(tAcA(0, m, 0)) < LEGAL_BLK_M;  // blk_m coord < residue_m
    }
    // Set predicates for n bounds
    CUTLASS_PRAGMA_UNROLL
    for (int n = 0; n < size<0>(tBpB); ++n) {
      tBpB(n, 0) =
          get<0>(tBcB(0, n, 0)) < LEGAL_BLK_N;  // blk_n coord < residue_n
    }

    // Acquire both producers before releasing the CTA to issue its copies.
    // One CTA barrier suffices for the two independent input tiles.
    auto wait_for_update = [&](const int k) {
      if (thread_idx == 0) {
        while (!task_table(blockIdx_x, k).load(cuda::memory_order_acquire)) {
          if constexpr (enable_static_pivoting) __nanosleep(kDependencySleepNs);
        }
        while (!task_table(k, blockIdx_y).load(cuda::memory_order_acquire)) {
          if constexpr (enable_static_pivoting) __nanosleep(kDependencySleepNs);
        }
      }
      __syncthreads();
    };

    // Shared issue path for initial prefetch and steady-state refills.
    // The caller owns remaining-work accounting and producer readiness.
    auto issue_stage = [&](const int pipe) {
      copy_if(gmem_tiled_copy_A, tApA, tAgA(_, _, _, *k_tile_iter),
              tAsA(_, _, _, pipe));
      copy_if(gmem_tiled_copy_B, tBpB, tBgB(_, _, _, *k_tile_iter),
              tBsB(_, _, _, pipe));
      cp_async_fence();
      ++k_tile_iter;
    };

    wait_for_update(0);
    CUTLASS_PRAGMA_UNROLL
    for (int pipe = 0; pipe < Stages - 1; ++pipe) {
      issue_stage(pipe);
      --k_tile_count;
    }

    //
    // Copy Atom retiling
    //

    auto smem_tiled_copy_A = make_tiled_copy_A(SmemCopyAtomA{}, tiled_mma);
    auto smem_thr_copy_A = smem_tiled_copy_A.get_thread_slice(thread_idx);
    Tensor tCsA = smem_thr_copy_A.partition_S(sA);  // (CPY,CPY_M,CPY_K,PIPE)
    Tensor tCrA_copy_view =
        smem_thr_copy_A.retile_D(tCrA);  // (CPY,CPY_M,CPY_K)
    CUTE_STATIC_ASSERT_V(size<1>(tCsA) == size<1>(tCrA_copy_view));  // CPY_M
    CUTE_STATIC_ASSERT_V(size<2>(tCsA) == size<2>(tCrA_copy_view));  // CPY_K

    auto smem_tiled_copy_B = make_tiled_copy_B(SmemCopyAtomB{}, tiled_mma);
    auto smem_thr_copy_B = smem_tiled_copy_B.get_thread_slice(thread_idx);
    Tensor tCsB = smem_thr_copy_B.partition_S(sB);  // (CPY,CPY_N,CPY_K,PIPE)
    Tensor tCrB_copy_view =
        smem_thr_copy_B.retile_D(tCrB);  // (CPY,CPY_N,CPY_K)
    CUTE_STATIC_ASSERT_V(size<1>(tCsB) == size<1>(tCrB_copy_view));  // CPY_N
    CUTE_STATIC_ASSERT_V(size<2>(tCsB) == size<2>(tCrB_copy_view));  // CPY_K

    //
    // PIPELINED MAIN LOOP
    //

    // Current pipe index in smem to read from
    int smem_pipe_read = 0;
    // Current pipe index in smem to write to
    int smem_pipe_write = Stages - 1;

    Tensor tCsA_p = tCsA(_, _, _, smem_pipe_read);
    Tensor tCsB_p = tCsB(_, _, _, smem_pipe_read);

    // Size of the register pipeline
    const auto K_BLOCK_MAX = size<2>(tCrA);

    // This MMA layout always has a register pipeline.
    static_assert(K_BLOCK_MAX > 1);
    cp_async_wait<Stages - 2>();
    __syncthreads();
    copy(smem_tiled_copy_A, tCsA_p(_, _, Int<0>{}),
         tCrA_copy_view(_, _, Int<0>{}));
    copy(smem_tiled_copy_B, tCsB_p(_, _, Int<0>{}),
         tCrB_copy_view(_, _, Int<0>{}));

    CUTLASS_PRAGMA_NO_UNROLL
    for (; k_tile_count > -(Stages - 1); --k_tile_count) {
      // Pipeline the outer products with a static for loop.
      //
      // Note, the for_each() function is required here to ensure `k_block` is
      // of type Int<N>.
      for_each(make_int_sequence<K_BLOCK_MAX>{}, [&](auto k_block) {
        if (k_block == K_BLOCK_MAX - 1) {
          // Slice the smem_pipe_read smem
          tCsA_p = tCsA(_, _, _, smem_pipe_read);
          tCsB_p = tCsB(_, _, _, smem_pipe_read);

          // Commit the smem for smem_pipe_read
          cp_async_wait<Stages - 2>();
          __syncthreads();
        }

        // Load A, B shmem->regs for k_block+1
        auto k_block_next = (k_block + Int<1>{}) % K_BLOCK_MAX;  // static
        copy(smem_tiled_copy_A, tCsA_p(_, _, k_block_next),
             tCrA_copy_view(_, _, k_block_next));
        copy(smem_tiled_copy_B, tCsB_p(_, _, k_block_next),
             tCrB_copy_view(_, _, k_block_next));
        // Copy gmem to smem before computing gemm on each k-pipe
        if (k_block == 0) {
          // Set all predicates to false if we are going to overshoot bounds
          if (k_tile_count <= 0) {
            clear(tApA);
            clear(tBpB);
          }

          if (*k_tile_iter % TILE_NUM_IN_BLOCK == 0 &&
              *k_tile_iter < size<3>(tAgA)) {
            wait_for_update(*k_tile_iter / TILE_NUM_IN_BLOCK);
          }
          issue_stage(smem_pipe_write);

          // Advance the shared-memory ring after issuing the refill.
          smem_pipe_write = smem_pipe_read;
          ++smem_pipe_read;
          smem_pipe_read = (smem_pipe_read == Stages) ? 0 : smem_pipe_read;
        }

        // Thread-level register gemm for k_block
        cute::gemm(tiled_mma, accum, tCrA(_, _, k_block), tCrB(_, _, k_block),
                   accum);
      });
    }
  }

  // All readers and async writers must finish before reusing the tile union.
  cp_async_wait<0>();
  __syncthreads();

  ////////////// Epilogue Start //////////////

  Tensor sC = make_tensor(make_smem_ptr(smem.factorize.smem_c.data()),
                          SmemLayoutC{});  // (BLK_M,BLK_N)
  Tensor sDiag = make_tensor(make_smem_ptr(smem.factorize.smem_diag.data()),
                             SmemLayoutC{});  // (BLK_M)

  Tensor tCsC = thr_mma.partition_C(sC);  // (MMA,MMA_M,MMA_N)

  CUTLASS_PRAGMA_UNROLL
  for (int i = 0; i < size(accum); ++i) {
    tCsC(i) = -accum(i);
  }

  if (blockIdx_x != blockIdx_y) {
    const auto blockIdx_diag = min(blockIdx_x, blockIdx_y);
    if (thread_idx == 0) {
      while (true != task_table(blockIdx_diag, blockIdx_diag)
                         .load(cuda::memory_order_acquire)) {
        __nanosleep(kDependencySleepNs);
      }
    }
    __syncthreads();

    // Get the appropriate blocks for this thread block
    const Tensor gDiag =
        local_tile(mC, TileShape{}, make_coord(blockIdx_diag, blockIdx_diag, _),
                   Step<_1, _1, X>{});  // (BLK_M,BLK_N)

    // Partition the copying of C tiles across the threads
    GmemTiledCopyC gmem_tiled_copy_C;
    auto gmem_thr_copy_C = gmem_tiled_copy_C.get_slice(thread_idx);

    Tensor tDgD = gmem_thr_copy_C.partition_S(gDiag);  // (ACPY,ACPY_M,ACPY_N)
    Tensor tDsD = gmem_thr_copy_C.partition_D(sDiag);  // (ACPY,ACPY_M,ACPY_N)

    copy(gmem_tiled_copy_C, tDgD, tDsD);
    cp_async_fence();
  }

  cp_async_wait<0>();
  __syncthreads();

  if (blockIdx_x < blockIdx_y) {
    // TRSM Upper Lx=A
    forward_solve_tile<TriangularDiagonal::unit>(thread_idx, LEGAL_BLK_N, sDiag,
                                                 sC, gC);
  } else if (blockIdx_x > blockIdx_y) {
    solve_right_upper<enable_static_pivoting>(thread_idx, LEGAL_BLK_M, sDiag,
                                              sC, gC);
  } else {
    // GETRF diagonal LU=A
    if constexpr (enable_static_pivoting) {
      factor_with_static_pivot(thread_idx, sC, pivot_count_ptr, criterion);
    } else {
      factor_diagonal_with_recovery(thread_idx, LEGAL_BLK_M, sC, sDiag);
    }
    copy_if(tCpC, tCsC, tCgC);
  }

  __syncthreads();
  if (thread_idx == 0) {
    task_table(blockIdx_x, blockIdx_y).store(true, cuda::memory_order_release);
  }
}

template <bool StaticPivot, bool vectorized, int MinBlocks>
cdlsStatus_t TiledGetrf<StaticPivot, vectorized, MinBlocks>::call(
    const ShapeType m, T* C, const ShapeType ldc, void* const workspace,
    int* const pivot_count, const T criterion, const cudaStream_t stream,
    const int panels) {
  using namespace cute;

  // Public entry points validate the square matrix and caller-owned storage.
  if (cudaMemsetAsync(workspace, 0, TaskWorkspace::bytes(m), stream) !=
      cudaSuccess)
    return CDLS_STATUS_EXECUTION_FAILED;
  TaskWorkspace tasks(workspace);

  const auto pivot_count_ptr =
      reinterpret_cast<cuda::atomic<int>*>(pivot_count);
  static_assert(sizeof(int) == sizeof(cuda::atomic<int>));

  dim3 dimBlock(size(TiledMma{}));
  dim3 dimGrid(size(ceil_div(m, bM{})), size(ceil_div(m, bN{})));
  if (panels > 0) {
    const auto tiles = ceil_div(m, bM{});
    // index_to_coord enumerates complete panel borders in dependency order.
    dimGrid = dim3(panels * (2 * tiles - panels));
  }

  const auto smem_byte = sizeof(Smem);

  // Every tile reserves the diagonal and factor buffers beyond the default
  // shared-memory budget, so all configurations opt in at launch.
  if (cudaFuncSetAttribute(getrf_tiled_kernel<TiledGetrf>,
                           cudaFuncAttributeMaxDynamicSharedMemorySize,
                           smem_byte) != cudaSuccess)
    return CDLS_STATUS_EXECUTION_FAILED;

  getrf_tiled_kernel<TiledGetrf><<<dimGrid, dimBlock, smem_byte, stream>>>(
      m, C, ldc, tasks.next, tasks.complete, pivot_count_ptr, criterion);
  return cudaPeekAtLastError() == cudaSuccess ? CDLS_STATUS_SUCCESS
                                              : CDLS_STATUS_EXECUTION_FAILED;
}

}  // namespace cdls::cuda_detail::getrf
