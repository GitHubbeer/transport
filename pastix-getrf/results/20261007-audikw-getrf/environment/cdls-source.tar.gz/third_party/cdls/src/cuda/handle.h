#pragma once

#include <cdls/internal/common.h>
#include <cublas_v2.h>

// CUDA-only ownership; the public/common handle remains the first member.
struct CudaHandle {
  cdlsHandle common;
  cublasHandle_t blas;
};
