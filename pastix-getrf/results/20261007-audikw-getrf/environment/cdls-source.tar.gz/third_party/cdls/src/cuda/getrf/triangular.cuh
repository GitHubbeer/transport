#pragma once

#include <cute/tensor.hpp>

#include "../../common/getrf/triangular.h"
#include "config.cuh"
#include "numeric.cuh"

namespace cdls::cuda_detail::getrf {

using cdls::detail::getrf::TriangularDiagonal;

struct CudaSolveOps {
  CUTE_DEVICE double divide(double value, double pivot) const {
    return value / pivot;
  }
  template <int Lanes, class Rhs>
  CUTE_DEVICE double broadcast(double value, int source, int k, int line,
                               Rhs& rhs) const {
    if (threadIdx.x % Lanes == source) rhs(k, line) = value;
    __syncwarp();
    return rhs(k, line);
  }
  CUTE_DEVICE void finish_group() const {}
  CUTE_DEVICE void finish() const {}
};

template <TriangularDiagonal Mode, class Coefficients, class Rhs, class Output>
CUTE_DEVICE void forward_solve_tile(unsigned tid, int bound,
                                    const Coefficients& coefficients, Rhs& rhs,
                                    Output& output) {
  cdls::detail::getrf::forward_solve<kTileExtent, kRhsLanes, Mode>(
      tid, bound, coefficients, rhs, output, CudaSolveOps{});
}

// Owns preparation and consumption of this CTA's private diagonal copy.
// Global LU factors remain unchanged; the vote/barrier publishes reciprocals.
template <bool enable_static_pivoting, class TensorDiag, class TensorTile,
          class TensorOutput>
CUTE_DEVICE void solve_right_upper(int tid, int bound, TensorDiag& diagonal,
                                   TensorTile& tile, TensorOutput& output) {
  using namespace cute;
  // Views only: no transpose kernel, storage, or data copies.
  const auto coefficients =
      make_tensor(diagonal.data(), select<1, 0>(diagonal.layout()));
  auto rhs = make_tensor(tile.data(), select<1, 0>(tile.layout()));
  auto result = make_tensor(output.data(), select<1, 0>(output.layout()));

  if constexpr (enable_static_pivoting) {
    forward_solve_tile<TriangularDiagonal::raw>(tid, bound, coefficients, rhs,
                                                result);
    return;
  }

  // A lower tile always depends on a complete 64x64 diagonal. Safe values
  // become reciprocals; extreme values stay raw for guarded division.
  int unsafe = 0;
  if (tid < kTileExtent) {
    const double pivot = diagonal(tid, tid);
    unsafe = !reciprocal_safe(pivot);
    if (!unsafe) diagonal(tid, tid) = 1.0 / pivot;
  }
  // One vote publishes cached values and selects the fast path for every size.
  if (__syncthreads_or(unsafe) == 0) {
    forward_solve_tile<TriangularDiagonal::safe_reciprocals>(
        tid, bound, coefficients, rhs, result);
    return;
  }
  forward_solve_tile<TriangularDiagonal::mixed_reciprocals>(
      tid, bound, coefficients, rhs, result);
}

}  // namespace cdls::cuda_detail::getrf
