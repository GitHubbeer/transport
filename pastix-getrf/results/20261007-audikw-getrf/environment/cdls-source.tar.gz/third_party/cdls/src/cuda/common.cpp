#include <cdls/common.h>
#include <cuda_runtime_api.h>

#include <new>

#include "handle.h"

extern "C" cdlsStatus_t cdlsCreate(cdlsHandle_t* handle) {
  if (handle == nullptr) return CDLS_STATUS_INVALID_VALUE;
  *handle = nullptr;
  auto* cuda_handle = new (std::nothrow) CudaHandle{};
  if (!cuda_handle) return CDLS_STATUS_ALLOC_FAILED;

  cudaStream_t work = nullptr, memset_stream = nullptr;
  if (cudaStreamCreateWithFlags(&work, cudaStreamNonBlocking) != cudaSuccess) {
    delete cuda_handle;
    return CDLS_STATUS_EXECUTION_FAILED;
  }
  if (cudaStreamCreateWithFlags(&memset_stream, cudaStreamNonBlocking) != cudaSuccess) {
    cudaStreamDestroy(work);
    delete cuda_handle;
    return CDLS_STATUS_EXECUTION_FAILED;
  }
  const auto status = cublasCreate(&cuda_handle->blas);
  if (status != CUBLAS_STATUS_SUCCESS) {
    cudaStreamDestroy(work);
    cudaStreamDestroy(memset_stream);
    delete cuda_handle;
    return status == CUBLAS_STATUS_ALLOC_FAILED ? CDLS_STATUS_ALLOC_FAILED
                                                : CDLS_STATUS_NOT_INITIALIZED;
  }
  cuda_handle->common.stream_work = work;
  cuda_handle->common.stream_memset = memset_stream;
  *handle = &cuda_handle->common;
  return CDLS_STATUS_SUCCESS;
}

extern "C" cdlsStatus_t cdlsDestroy(cdlsHandle_t handle) {
  if (handle == nullptr || handle->stream_work == nullptr ||
      handle->stream_memset == nullptr) return CDLS_STATUS_INVALID_VALUE;

  auto* cuda_handle = reinterpret_cast<CudaHandle*>(handle);
  const auto blas_status = cublasDestroy(cuda_handle->blas);
  const auto work_status = cudaStreamDestroy(static_cast<cudaStream_t>(handle->stream_work));
  const auto memset_status = cudaStreamDestroy(static_cast<cudaStream_t>(handle->stream_memset));
  delete cuda_handle;
  return blas_status == CUBLAS_STATUS_SUCCESS && work_status == cudaSuccess &&
                 memset_status == cudaSuccess
             ? CDLS_STATUS_SUCCESS : CDLS_STATUS_EXECUTION_FAILED;
}
