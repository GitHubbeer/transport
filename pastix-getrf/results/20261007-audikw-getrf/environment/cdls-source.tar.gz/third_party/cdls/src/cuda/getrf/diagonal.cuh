#pragma once

#include <cuda/atomic>
#include <cute/tensor.hpp>

#include "../../common/getrf/panel.h"
#include "../../common/getrf/static_pivot.h"
#include "config.cuh"
#include "numeric.cuh"

namespace cdls::cuda_detail::getrf {

// Keep sparse frontier publication predicated: branching around these few
// stores adds costly warp reconvergence at every pivot.
CUTE_DEVICE void store_frontier_if(double* destination, double value,
                                   bool enabled) {
  const unsigned address =
      static_cast<unsigned>(__cvta_generic_to_shared(destination));
  asm volatile(
      "{ .reg .pred p; setp.ne.u32 p, %2, 0; @p st.shared.f64 [%0], %1; }" ::
          "r"(address),
      "d"(value), "r"(int(enabled))
      : "memory");
}

// Keep the full diagonal tile in registers. Shared memory communicates only
// the next pivot frontier and the finalized factors.
template <class TensorSmem, class TensorBackup>
CUTE_DEVICE bool try_register_lu(const int tid, TensorSmem& c,
                                 TensorBackup& backup) {
  const int row0 = tid % kRegisterAxis;
  const int col0 = tid / kRegisterAxis;
  double x[kRegisterValues][kRegisterValues];
  bool unsafe = false;
#pragma unroll
  for (int i = 0; i < kRegisterValues; ++i) {
#pragma unroll
    for (int j = 0; j < kRegisterValues; ++j) {
      x[i][j] = c(row0 + kRegisterAxis * i, col0 + kRegisterAxis * j);
      backup(row0 + kRegisterAxis * i, col0 + kRegisterAxis * j) = x[i][j];
    }
  }
  __syncthreads();
#pragma unroll
  for (int k = 0; k < kTileExtent - 1; ++k) {
    const double diagonal = c(k, k);
    const bool safe = reciprocal_safe(diagonal);
    unsafe |= !safe;
    const double inverse = 1.0 / diagonal;
    double l[kRegisterValues], u[kRegisterValues];
#pragma unroll
    for (int i = 0; i < kRegisterValues; ++i) {
      const int row = row0 + kRegisterAxis * i;
      const double value = c(row, k);
      l[i] = value * inverse;
      const int col = col0 + kRegisterAxis * i;
      u[i] = c(k, kRegisterAxis * i > k ? col : max(col, k));
    }
#pragma unroll
    for (int i = 0; i < kRegisterValues; ++i) {
#pragma unroll
      for (int j = 0; j < kRegisterValues; ++j) {
        // Discarded values may also be updated. Keeping each remaining
        // register group uniform avoids divergent arithmetic at every pivot.
        if (kRegisterAxis * i + (kRegisterAxis - 1) > k &&
            kRegisterAxis * j + (kRegisterAxis - 1) > k) {
          x[i][j] -= l[i] * u[j];
        }
      }
    }
#pragma unroll
    for (int i = 0; i < kRegisterValues; ++i) {
      const int row = row0 + kRegisterAxis * i;
      if (kRegisterAxis * i + (kRegisterAxis - 1) > k)
        store_frontier_if(&c(row, k + 1), x[i][(k + 1) / kRegisterAxis],
                          col0 == ((k + 1) % kRegisterAxis) && row > k);
    }
#pragma unroll
    for (int j = 0; j < kRegisterValues; ++j) {
      const int col = col0 + kRegisterAxis * j;
      if (kRegisterAxis * j + (kRegisterAxis - 1) > k + 1)
        store_frontier_if(&c(k + 1, col), x[(k + 1) / kRegisterAxis][j],
                          row0 == ((k + 1) % kRegisterAxis) && col > k + 1);
    }
    // Frontier writes cannot overlap this pivot's row/column reads. Complete
    // those reads before replacing the old column with its final L values.
    __syncthreads();
#pragma unroll
    for (int i = 0; i < kRegisterValues; ++i) {
      const int row = row0 + kRegisterAxis * i;
      if (kRegisterAxis * i + (kRegisterAxis - 1) > k)
        store_frontier_if(&c(row, k), l[i],
                          col0 == (k % kRegisterAxis) && row > k);
    }
  }
  // Nothing has been published to global memory yet. A uniform failure result
  // lets the caller restore the input tile and use the original division path.
  return __syncthreads_or(unsafe) == 0;
}

struct CudaPivotCount {
  cuda::atomic<int>* value;
  CUTE_DEVICE void increment() const {
    value->fetch_add(1, cuda::memory_order_relaxed);
  }
};
template <class TensorSmem>
CUTE_DEVICE void factor_with_static_pivot(unsigned tid, TensorSmem& tile,
                                          cuda::atomic<int>* count,
                                          double criterion) {
  cdls::detail::getrf::factor_with_static_pivot<kTileExtent, kRegisterAxis,
                                                kTileThreads>(
      tid, kTileExtent, tile, CudaPivotCount{count}, criterion);
}

// Inner-panel organization adapted from ck_getrf::diagonal (AMD).
// Upstream notices: third_party/ck_getrf_notices. Each pivot publishes a
// different shared row, so one publication barrier suffices inside a panel.
template <int P, class TensorSmem>
CUTE_DEVICE void lu_panel(const int tid, const int bound, TensorSmem& c) {
  for (int p = 0; p < bound; p += P) {
    double x[P];
#pragma unroll
    for (int j = 0; j < P; ++j) x[j] = tid < kTileExtent ? c(tid, p + j) : 0.0;
#pragma unroll
    for (int k = 0; k < P; ++k) {
      if (p + k < bound) {
        if (tid == p + k) {
#pragma unroll
          for (int j = k; j < P; ++j) c(tid, p + j) = x[j];
        }
        __syncthreads();
        if (tid > p + k && tid < bound) {
          x[k] /= c(p + k, p + k);
#pragma unroll
          for (int j = k + 1; j < P; ++j) x[j] -= x[k] * c(p + k, p + j);
        }
      }
    }
    // Readers must finish before panel writeback can overwrite published rows.
    __syncthreads();
    cdls::detail::getrf::finish_lu_panel<kTileExtent, P, kTileThreads>(
        tid, p, bound, c, x);
  }
}

// One CTA owns the entire transaction. Failed speculation restores the original
// tile before panel LU; the caller may publish factors only after this returns.
template <class TensorSmem, class TensorBackup>
CUTE_DEVICE void factor_diagonal_with_recovery(int tid, int bound,
                                               TensorSmem& tile,
                                               TensorBackup& backup) {
  if (bound == kTileExtent) {
    if (try_register_lu(tid, tile, backup)) return;
    for (int idx = tid; idx < kTileExtent * kTileExtent; idx += kTileThreads)
      tile(idx % kTileExtent, idx / kTileExtent) =
          backup(idx % kTileExtent, idx / kTileExtent);
    __syncthreads();
  }
  // Partial tiles and restored full tiles share the same robust path.
  lu_panel<kPanelWidth>(tid, bound, tile);
}

}  // namespace cdls::cuda_detail::getrf
