#include <cdls/getrf.h>

#include <algorithm>
#include <climits>

#include "../common/getrf/hybrid.h"
#include "getrf/small.cuh"
#include "getrf/tiled.cuh"
#include "handle.h"

using namespace cdls::cuda_detail::getrf;

namespace {
bool supported_square(long m, long n) {
  return m == n && TaskWorkspace::supports_extent(m);
}

bool valid_factorization(cdlsHandle_t handle, long m, long n,
                         const double* matrix, long lda,
                         const void* workspace) {
  return supported_square(m, n) && handle != nullptr && lda >= m &&
         matrix != nullptr && workspace != nullptr;
}

// Right-looking outer panels, inspired by ck_getrf::factorize_hybrid:
// the prefix kernel produces L21/U12; cuBLAS updates the untouched A22.
template <bool vectorized>
cdlsStatus_t getrf_no_pivot(cdlsHandle_t handle, long n, double* matrix,
                            long lda, void* workspace, int* pivot_count) {
  const auto stream = static_cast<cudaStream_t>(handle->stream_work);
  using Fused = TiledGetrf<false, vectorized, kLargeRegisterMinBlocks>;
  using Prefix = TiledGetrf<false, vectorized, kBalancedMinBlocks>;
  if (n <= kFusedMaxExtent)
    return Fused::call(n, matrix, lda, workspace, pivot_count, 0.0, stream, 0);

  // cuBLAS takes int dimensions; the tiled kernel retains 64-bit addressing.
  if (n > INT_MAX || lda > INT_MAX)
    return Prefix::call(n, matrix, lda, workspace, pivot_count, 0.0, stream, 0);

  auto blas = reinterpret_cast<CudaHandle*>(handle)->blas;
  if (cublasSetStream(blas, stream) != CUBLAS_STATUS_SUCCESS)
    return CDLS_STATUS_EXECUTION_FAILED;
  // A100 paired measurements favor panels up to 2048 and a fused tail up
  // to 4224. Shorten the final prefix to leave a tail near 3072, balancing
  // prefix work against the tail's single-CTA configuration.

  const double minus = -1.0, plus = 1.0;
  return cdls::detail::getrf::factorize_hybrid(
      n, matrix, lda, kFusedMaxExtent, kTileExtent,
      [](long remaining) {
        return std::min<long>(
            kHybridPanelExtent,
            ((remaining - kHybridTargetTailExtent + kTileExtent - 1) /
             kTileExtent) *
                kTileExtent);
      },
      [&](long remaining, double* base, int panels) {
        if (panels == 0)
          return Fused::call(remaining, base, lda, workspace, pivot_count, 0.0,
                             stream, 0);
        return Prefix::call(remaining, base, lda, workspace, pivot_count, 0.0,
                            stream, panels);
      },
      [&](double* base, int trailing, int width) {
        return cublasDgemm(blas, CUBLAS_OP_N, CUBLAS_OP_N, trailing, trailing,
                           width, &minus, base + width, static_cast<int>(lda),
                           base + width * lda, static_cast<int>(lda), &plus,
                           base + width + width * lda,
                           static_cast<int>(lda)) == CUBLAS_STATUS_SUCCESS
                   ? CDLS_STATUS_SUCCESS
                   : CDLS_STATUS_EXECUTION_FAILED;
      });
}
}  // namespace

extern "C" cdlsStatus_t cdlsDgetrf_bufferSize(const long m, const long n,
                                              size_t* buffer_size) {
  if (buffer_size == nullptr || !supported_square(m, n))
    return CDLS_STATUS_INVALID_VALUE;
  *buffer_size = TaskWorkspace::bytes(m);
  return CDLS_STATUS_SUCCESS;
}

extern "C" cdlsStatus_t cdlsDgetrf(const cdlsHandle_t handle, const long m,
                                   const long n, double* C, const long ldc,
                                   void* const workspace,
                                   int* const pivot_count) {
  if (!valid_factorization(handle, m, n, C, ldc, workspace)) {
    return CDLS_STATUS_INVALID_VALUE;
  }
  const auto stream = static_cast<cudaStream_t>(handle->stream_work);

  // One warp avoids the tiled scheduler's overhead for the smallest matrices.
  if (m <= kWarpSize) {
    getrf_small_kernel<<<1, kWarpSize, 0, stream>>>(static_cast<int>(m), C,
                                                    ldc);
    return cudaPeekAtLastError() == cudaSuccess ? CDLS_STATUS_SUCCESS
                                                : CDLS_STATUS_EXECUTION_FAILED;
  }

  // Vector copies require both even extents and a 16-byte aligned origin.
  const bool vectorized =
      m % 2 == 0 && ldc % 2 == 0 &&
      reinterpret_cast<std::uintptr_t>(C) % kVectorCopyBytes == 0;
  if (vectorized)
    return getrf_no_pivot<true>(handle, m, C, ldc, workspace, pivot_count);
  return getrf_no_pivot<false>(handle, m, C, ldc, workspace, pivot_count);
}

cdlsStatus_t cdlsDgetrf_static_pivoting(const cdlsHandle_t handle, long m,
                                        long n, double* C, long ldc,
                                        void* workspace, int* pivot_count,
                                        double criterion) {
  if (!valid_factorization(handle, m, n, C, ldc, workspace) ||
      pivot_count == nullptr) {
    return CDLS_STATUS_INVALID_VALUE;
  }
  using Kernel = TiledGetrf<true, false, kBalancedMinBlocks>;
  return Kernel::call(m, C, ldc, workspace, pivot_count, criterion,
                      static_cast<cudaStream_t>(handle->stream_work), 0);
}
