#pragma once

#include <cuda_runtime.h>

#include "config.cuh"

namespace cdls::cuda_detail::getrf {

__global__ void getrf_small_kernel(const int n, double* a, const long lda) {
  const int row = threadIdx.x;
  double values[kWarpSize];
#pragma unroll
  for (int j = 0; j < kWarpSize; ++j) {
    values[j] = row < n && j < n ? a[row + j * lda] : 0.0;
  }
#pragma unroll
  for (int k = 0; k < kWarpSize; ++k) {
    if (k < n) {
      const double diagonal = __shfl_sync(kWarpMask, values[k], k);
      if (row > k) values[k] /= diagonal;
      const double l = values[k];
#pragma unroll
      for (int j = k + 1; j < kWarpSize; ++j) {
        const double u = __shfl_sync(kWarpMask, values[j], k);
        if (row > k) values[j] -= l * u;
      }
    }
  }
#pragma unroll
  for (int j = 0; j < kWarpSize; ++j) {
    if (row < n && j < n) a[row + j * lda] = values[j];
  }
}

}  // namespace cdls::cuda_detail::getrf
